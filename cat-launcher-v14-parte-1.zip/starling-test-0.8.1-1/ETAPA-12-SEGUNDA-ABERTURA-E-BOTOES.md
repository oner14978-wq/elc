# ETAPA 12 - segunda abertura rápida, sem H e "...", botões roxos no jogo - NÃO COMPILADO, NÃO TESTADO NO APARELHO

Sem cargo, NDK, Android SDK, rede ou aparelho neste ambiente. Verificado só: javac sem erro de sintaxe em CatHomeActivity.java.

## Feito
- CatHomeActivity.java: installedVersions() devolve na hora a lista salva em files/cat-installed.json (escrita atômica);
  o motor reconfere em segundo plano (uma checagem por vez). Lista salva vazia/ausente: pergunta ao motor e grava.
  removeVersion bem-sucedido grava "[]". Antes a lista esperava CatCore.start (biblioteca nativa + Keystore) a cada abertura.
- android_control_ui.rs: const CAT_HIDE_HORIZON_BUTTONS = true: não desenha nem aceita toque no botão H (hub flutuante)
  nem no "..." (Action::More). Consequência: F3/F5/Chat/Keys do painel expandido ficam inacessíveis por toque.
- android_control_ui.rs: button() (Back, Keys, Mouse, LMB/RMB) agora desenha botão roxo próprio (contorno, corpo, brilho, sombra),
  sem textura de pedra.

## Já existia (ETAPA 10/11), conferido por leitura
- Java 25: starling_account::java::install confere sha256 e não baixa de novo; em falha o jre25 é mantido para a nova tentativa.
  Só é apagado depois do preparo concluído.
- install() = download + Java + preparo numa thread própria; a ponte JS roda fora da thread de UI.

## NÃO feito / NÃO verificado
- Compilar, instalar o APK, JOGAR abrir o Minecraft, tela preta, ANR, memória, texturas: nada testado.
- Botões roxos têm só estado normal; pressionado/selecionado/desativado/animação não foram feitos no Rust.
- Os botões do menu principal do Minecraft (Singleplayer etc.) vêm do pacote de recursos do jogo e não foram trocados.
- Causa do travamento (ANR) não investigada.

# ETAPA 13 - registro permanente (SQLite) - NÃO COMPILADO, NÃO TESTADO NO APARELHO
- NOVO CatRegistry.java: banco cat-registry.db (databases/ privado do app; sobrevive a fechar, reiniciar e atualizar o APK).
  Estados: installing / installed / damaged. "installed" só é gravado depois que o motor informa arquivos prontos E preparados.
- CatHomeActivity: installedVersions() lê do banco na hora (sem esperar o motor); reconcileRegistry() em segundo plano:
  motor que não responde não apaga nada; motor que não encontra a versão -> damaged (continua listada; instalar de novo reaproveita
  arquivos com hash bom). installVersion grava installing e um observador grava installed ao concluir. interruptedVersions() lista
  instalações interrompidas. removeVersion bloqueado durante instalação; mundos/configurações não são tocados (motor).
- index.html: confirmação também no remover da lista (antes só na tela de download).
- Importa uma vez o cat-installed.json da etapa 12.
- NÃO feito: a página ainda não mostra "interrompida/danificada" (a ponte oferece interruptedVersions); barra com as 7 etapas do pedido
  (a barra da ETAPA 10 tem as etapas do motor); limite de RAM/carga progressiva de regiões (é do motor Rust, não mexi); testes 1-7.

# ETAPA 14 - sem tela Diagnostics automática - NÃO COMPILADO, NÃO TESTADO NO APARELHO
- LauncherActivity: removida a rota para DiagnosticsActivity quando StartupRecovery.interrupted(). Agora chama
  StartupRecovery.recoverSilently() e abre a tela inicial (home()) direto.
- StartupRecovery.recoverSilently(): em thread de fundo, se a abertura anterior foi interrompida, registra no log, marca
  recovery_offered na sessão (as evidências ficam guardadas para exportar) e apaga o marcador starling-starting: a mesma
  tentativa nunca é tratada duas vezes (sem ciclo).
- Não toca em SQLite, versões, mundos nem configurações. O banco (CatRegistry) é reconciliado por CatHomeActivity, e
  instalação interrompida aparece por interruptedVersions().
- Diagnóstico mantido: DiagnosticsActivity, logs, exportação e atalho do launcher continuam. Acesso manual: engrenagem da
  versão na tela inicial -> pergunta "Abrir o diagnóstico?" (novo CatHomeActivity.openDiagnostics()).
- Também ao voltar do Minecraft: o caminho "voltar do jogo" já ia para play()/home() e nunca para o diagnóstico.
- Limite: se o próprio jogo travar de novo, o marcador volta a existir, mas só é consumido em silêncio na próxima abertura.

# ETAPA 15 - início mais rápido: análise e medição - NÃO COMPILADO, NENHUM TEMPO MEDIDO
Lido no código (sem aparelho): installed()/accounts::files() é só stat (barato); o Java 25 e o kit só são baixados/preparados
quando faltam (hash conferido); o preparo não roda de novo quando os recursos já existem (so ao faltar sounds.json).
Não achei verificação completa repetida a cada JOGAR no que li; não li o carregamento gráfico nem o da JVM do motor.
- CatHomeActivity.incompatibility(): versão "installed" no registro SQLite pula prepared() (chamada ao motor, que espera
  CatCore.start) e a checagem de espaço. Vulkan/ABI/Android continuam conferidos.
- Logs reais: "JOGAR: checks took N ms", "JOGAR: game activity requested N ms after the click" (tag starling) e, no Rust,
  "Horizon: load stage K (nome) at +N ms" por etapa de carga (resource_load.rs, só log).
- Para medir: adb logcat -s starling:I | grep -E "JOGAR|load stage". Tempos antes/depois: NÃO existem.
- NÃO feito: pré-preparo antecipado, ajuste de JVM/RAM, carga progressiva de regiões, barra: sem perfil não mexi às cegas.

# ETAPA 16 - inventário em uma janela só - NÃO COMPILADO, NÃO TESTADO NO JOGO
- Causa das duas janelas (catálogo criativo + inventário do jogador): a opção "Bedrock Inventory" (settings.bedrock_inventory,
  usada por creative_screen.rs::bedrock_show) vinha LIGADA por padrão e as configurações já salvas a mantinham ligada.
- horizon-client-render/src/settings.rs: padrão passa a false; a chave salva passa a ser "bedrockInventory" (liga) em vez de
  "javaCreativeInventory" (desliga): arquivos antigos, que só têm a chave antiga, passam a ler como desligado = janela única.
  Quem ligar a opção de novo em Opções mantém o layout dividido.
- Com a opção desligada o código já usa um só painel (CREATIVE_SHIFT = 0) e a aba "Inventário" (ícone do baú) mostra
  armadura, criação 2x2 e a mochila. Nenhuma lógica de arrastar/soltar foi alterada.
- Baú: container_screen.rs não tem relação com a tela criativa (Screen separado). Não achei no código um caminho que abra duas
  janelas ao abrir um baú; não consegui reproduzir. Se acontecer com a opção desligada, preciso de um print e do log.
- Texturas: não alterei nenhuma; não encontrei no código textura trocada. Sem comparação visual não afirmo nada.

# ETAPA 17 - controles de toque roxos - NÃO COMPILADO, NÃO TESTADO NO APARELHO, SEM APK
Dois sistemas de toque coexistem; os dois ficaram roxos:
1. android_controls.rs (a tela da imagem 1: joystick, espada, setas, >>, "...", barra de cima): usava as texturas do Bedrock
   baixadas (gui/bedrock/*) e, sem elas, um desenho de reserva cinza. Agora:
   - hud.rs: images.retain(...) deixa gui/bedrock/* fora do atlas (mesmo as já baixadas no celular); android_control_assets::fetch
     não baixa mais nada.
   - android_controls.rs, fitted_sprite (desenho de reserva): placa violeta com contorno escuro, brilho em cima e sombra embaixo,
     ícone branco; pressionado = face mais escura, chanfro invertido e ícone 1 pixel abaixo; joystick redondo violeta (base
     translúcida + botão); novos ícones de pixel: chat (balão), F3, F5, engrenagem, E (inventário, antes "..."); pause/setas/espada
     já existiam no desenho de reserva. Pause/Configurações não desenham mais placa dupla. draw_mcpe_bevel_button usa o violeta.
2. Sprites starling:touch/* (packaging/touch/make.py -> crates/horizon-client/assets/touch/*.png, REGERADOS: placa violeta limpa, ícones
   brancos com borda violeta escura, joystick e botão redondos). bedrock_touch::fetch_logged não baixa mais; apaga uma vez os
   sprites Bedrock gravados por versões anteriores (senão venceriam os do Cat Launcher).
- Nada de botão novo; funções e multitouch não foram tocados (só o desenho).
- Limites: o botão "Use" (colocar/usar) mantém o ícone de mira; o de bloco/ataque (Attack) tem a espada. A picareta da referência
  não foi aplicada porque não há controle separado de "quebrar" no código; criar um seria um botão novo.
- Os ícones são pixel art desenhado por mim, não os da imagem 2. Cores e tamanhos não foram vistos no aparelho.

# ETAPA 18 - sem jogador e sem "Customize..." no menu inicial - NÃO COMPILADO, NÃO TESTADO
- game/starling/own_skin.rs: const CAT_NO_TITLE_PLAYER = true; draw_title_player() sai no começo (não desenha o modelo, o nome nem o
  botão e nem lê o skin para essa tela). title_visible fica false, então title_layout_now() é None e os toques/cliques nessa área
  (on_title_player, title_player_at, press/drag/release em window_handler.rs e touch/mod.rs) deixam de agir sozinhos.
- Intocados: skin e página Skin Customization nas Opções, jogador na partida, inventário, controles, mundos, demais botões do menu.

# ETAPA 19 - Video Settings abre a página de duas colunas - NÃO COMPILADO, NÃO TESTADO NO APARELHO
- A tela da imagem 1 era Page::Graphics (graphics_ui + settings_shell, barra lateral Horizon). A da imagem 2 já existia: Page::Video
  (options_ui.rs), duas colunas, Display / Quality & Performance / Preferences, todas as opções ligadas a Opt::* reais
  (as mesmas já salvas em options.txt/horizon): ExclusiveMode, MaxFps, InactivityFps, GuiScale, Fullscreen, Gamma, GraphicsBackend,
  Preset, BiomeBlend, RenderDistance, ChunkBuilder, SimulationDistance, SmoothLighting, Clouds, Particles, Mipmaps, EntityShadows,
  EntityDistance, MenuBlur, CloudRange, CutoutLeaves, ImprovedTransparency, TextureFiltering, MaxAnisotropy, WeatherRadius.
- options_ui.rs: "Video Settings..." (options.video) agora abre Page::Video em vez de Page::Graphics. O teste que fixava o
  roteamento antigo foi invertido. Nenhuma opção foi criada ou removida.
- Para não perder Shaders, HDR, LOD/Far Detail, Performance e Advanced (só existem na tela antiga), a página Video ganhou UM botão no
  fim: "Shaders, HDR & More..." que abre Page::Graphics. Se preferir sem ele, apague essa linha (perde acesso a essas opções).
- Back/Done, rolagem e adaptação à tela são os da própria página Video (a mesma da imagem 2). Não reescrevi o sistema de opções.
- "horizon-ctl options video" continua abrindo Page::Graphics (CLI), "video-vanilla" abre Page::Video.

# ETAPA 20 - Options só com os botões originais - NÃO COMPILADO, NÃO TESTADO
- options_ui.rs: const CAT_VANILLA_OPTIONS = true. A página Options usa a lista original (FOV, Online, Skin Customization, Music &
  Sounds, Video Settings, Controls, Language, Chat Settings, Resource Packs, Accessibility, Telemetry Data (cinza, como no
  original), Credits & Attribution, Done). Saíram da página: Horizon Settings, Mods, Diagnostics (14 -> 12 botões + Done).
- Acessos que restam: Diagnostics = engrenagem da versão no launcher; Mods = botão Mods do menu inicial; Horizon Settings (Page::Horizon):
  só pelo "horizon-ctl options horizon" - SEM botão no jogo. Para devolver: CAT_VANILLA_OPTIONS = false.
- Teste "Options' pushes" atualizado. Visual dos botões não mudou (já usam os sprites do Minecraft).

# ETAPA 21 - versão instalada some da tela inicial depois do jogo - NÃO COMPILADO, NÃO TESTADO NO APARELHO
Causa provável (lida no código, não reproduzida): CatHomeActivity.listVersions() devolvia "[]" quando o motor não respondia (ocupado/parado
ao voltar do jogo); o JS aceitava "[]" como lista válida (VER=[]), e renderHome() só mostra versões que estão em VER, então a
versão instalada não aparecia. catResume() também não relia a lista.
- CatHomeActivity.listVersions(): se o motor não responde, devolve a única versão real do motor (GAME_VERSION) com installed vindo do
  registro SQLite.
- index.html: loadVers() nunca deixa VER vazio (só a versão real do motor; a lista fictícia de 12 versões foi removida);
  renderHome() mostra a união de VER e das instaladas do registro; catResume() chama loadVers() antes de syncInstalled().
- Checado: javac (sintaxe) e o JS do index.html carrega sem erro de sintaxe (node). Nada mais testado.
- LIMITE: o motor (Starling) só instala UMA versão, a fixada em Pins::starling() ("26.3"). Outras versões (1.8.9, snapshots...) não
  existem no motor; mostrá-las seria criar versões falsas. "Adicionar versão" com várias versões exige suporte do motor.
- A tela inicial não tem botão "Adicionar versão" próprio (a instalação é pela aba Versões) nem mostra o skin na lista; não alterei.
