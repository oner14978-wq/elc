//! Tamable animals (`TamableAnimal`): wolves with their variants, taming,
//! sitting, following and defending the owner, begging, anger and shaking
//! off water (`Wolf`, `WolfModel`).
use super::{
    Mob, MobEvent, MobWorld, PlayerView, Species, Who,
    anim::{Poses, State},
    goals::{
        Breed, Cx, Float, Goal, HurtByTarget, JUMP, LOOK, LeapAtTarget, LookAtPlayer, MOVE,
        MeleeAttack, NearestTarget, Panic, Prey, RandomLookAround, Stroll, TARGET, goal_clone,
        reduced,
    },
};
use horizon_core::geometry::trig::Mth;
use horizon_core::{
    geometry::{Aabb, Axis, Vec3},
    random::RandomSource,
};
use std::f32::consts::PI;

/// Wolf variants: registry name and texture file (`WolfVariants`).
pub const WOLF_VARIANTS: [(&str, &str); 9] = [
    ("pale", "wolf"),
    ("spotted", "wolf_spotted"),
    ("snowy", "wolf_snowy"),
    ("black", "wolf_black"),
    ("ashen", "wolf_ashen"),
    ("rusty", "wolf_rusty"),
    ("woods", "wolf_woods"),
    ("chestnut", "wolf_chestnut"),
    ("striped", "wolf_striped"),
];
/// The wolf variant a biome spawns (its high-priority `BiomeCheck`).
pub fn wolf_variant_for(biome: &str, has_tag: &dyn Fn(&str) -> bool) -> u8 {
    if has_tag("minecraft:is_savanna") {
        1
    } else if biome == "minecraft:grove" {
        2
    } else if biome == "minecraft:old_growth_pine_taiga" {
        3
    } else if biome == "minecraft:snowy_taiga" {
        4
    } else if has_tag("minecraft:is_jungle") {
        5
    } else if biome == "minecraft:forest" {
        6
    } else if biome == "minecraft:old_growth_spruce_taiga" {
        7
    } else if has_tag("minecraft:is_badlands") {
        8
    } else {
        0
    }
}
/// The default collar: red.
pub const RED: u8 = 14;

// AnimState slots: begging interest and the shake animation.
pub const INTEREST: usize = 0;
pub const SHAKE: usize = 1;

pub fn register(m: &mut Mob) {
    m.extra.color = RED;
    let food = m.kind.food.clone();
    let g = &mut m.ai.goals;
    g.add(1, Float);
    // `TamableAnimalPanicGoal(this, 1.5, PANIC_ENVIRONMENTAL_CAUSES)`.
    let mut panic = Panic::new(1.5);
    panic.environmental = true;
    g.add(1, TamePanic(panic));
    g.add(2, SitWhenOrdered);
    g.add(3, AvoidLlamas::new());
    g.add(4, LeapAtTarget::new(0.4));
    g.add(5, MeleeAttack::new(1.0, true));
    g.add(6, FollowOwner::new(1.0, 10.0, 2.0));
    g.add(7, Breed::new(1.0));
    g.add(8, Stroll::avoiding_water(1.0));
    g.add(9, Beg { food, ticks: 0 });
    g.add(10, LookAtPlayer::new(8.0));
    g.add(10, RandomLookAround::default());
    m.ai.targets.add(1, OwnerHurtBy { timestamp: 0 });
    m.ai.targets.add(2, OwnerHurt { timestamp: 0 });
    m.ai.targets.add(3, HurtByTarget::new().alert());
    m.ai.targets
        .add(4, NearestTarget::player(true).when(angry_at_player));
    m.ai.targets.add(
        5,
        NonTameTarget::new(NearestTarget::new(Prey::Filter(wolf_prey), false)),
    );
    m.ai.targets.add(
        6,
        NonTameTarget::new(NearestTarget::new(Prey::Filter(baby_turtle_on_land), false)),
    );
    m.ai.targets.add(
        7,
        NearestTarget::species(
            &[
                Species::Skeleton,
                Species::Stray,
                Species::Bogged,
                Species::WitherSkeleton,
            ],
            false,
        ),
    );
}
/// `Parrot.registerGoals`: a tamed parrot sits when told to and follows its
/// owner from five blocks away; it wanders to trees (`ParrotWanderGoal`) and
/// lands on its owner's shoulder.
pub fn register_parrot(m: &mut Mob) {
    let g = &mut m.ai.goals;
    g.add(0, TamePanic(Panic::new(1.25)));
    g.add(0, Float);
    g.add(1, LookAtPlayer::new(8.0));
    g.add(2, SitWhenOrdered);
    g.add(2, FollowOwner::new(1.0, 5.0, 1.0));
    g.add(2, Stroll::parrot(1.0));
    g.add(3, LandOnOwnersShoulder);
    g.add(3, super::goals::FollowMob::new(1.0, 3.0, 7.0));
}
/// `LandOnOwnersShoulderGoal`: a standing parrot, 100 ticks old, lands on
/// the shoulder of the owner it touches; the host does the landing.
#[derive(Clone, Debug)]
struct LandOnOwnersShoulder;
impl Goal for LandOnOwnersShoulder {
    goal_clone!();
    fn flags(&self) -> u8 {
        0
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        // ShoulderRidingEntity.canSitOnShoulder: rideCooldownCounter > 100.
        is_owner(m, cx.w)
            && owner(m, cx.w).is_some_and(|(_, _, spectator)| !spectator)
            && !m.extra.sitting
            && m.age > 100
    }
    fn tick(&mut self, m: &mut Mob, cx: &mut Cx) {
        if !m.extra.sitting
            && m.extra.leash.is_none()
            && is_owner(m, cx.w)
            && cx
                .w
                .selected_player()
                .is_some_and(|p| m.bounds().intersects(p.bounds))
        {
            cx.events
                .push(cx.w.route_player_event(MobEvent::ParrotToShoulder { mob: m.id }));
        }
    }
}
/// `NonTameRandomTargetGoal`: a tameable mob's prey target, only while it is
/// wild. Vanilla re-tests the subclass selector while hunting, so a baby
/// turtle that enters water stops being hunted.
#[derive(Clone, Debug)]
struct NonTameTarget(NearestTarget);
impl NonTameTarget {
    fn new(inner: NearestTarget) -> Self {
        Self(inner.named("NonTameRandomTargetGoal"))
    }
    fn prey_matches(prey: &Prey, who: Who, w: &MobWorld) -> bool {
        match prey {
            Prey::Player => who == Who::Player,
            Prey::Species(list) => match who {
                Who::Player => false,
                Who::Mob(id) => w.seen(id).is_some_and(|s| list.contains(&s.species)),
            },
            Prey::Filter(f) => match who {
                Who::Player => false,
                Who::Mob(id) => w.seen(id).is_some_and(f),
            },
        }
    }
}
impl Goal for NonTameTarget {
    goal_clone!();
    fn flags(&self) -> u8 {
        self.0.flags()
    }
    fn name(&self) -> &'static str {
        "NonTameRandomTargetGoal"
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        !m.extra.tame && self.0.can_use(m, cx)
    }
    fn can_continue(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        let Some(who) = m.ai.target else {
            return false;
        };
        Self::prey_matches(&self.0.prey, who, cx.w) && self.0.can_continue(m, cx)
    }
    fn start(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.0.start(m, cx)
    }
    fn stop(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.0.stop(m, cx)
    }
    fn tick(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.0.tick(m, cx)
    }
}
/// `Turtle.BABY_ON_LAND_SELECTOR`: a baby turtle out of water.
fn baby_turtle_on_land(s: &super::Seen) -> bool {
    s.species == Species::Turtle && s.baby && !s.in_water
}
/// `Wolf.PREY_SELECTOR`: sheep, rabbits and foxes.
fn wolf_prey(s: &super::Seen) -> bool {
    matches!(s.species, Species::Sheep | Species::Rabbit | Species::Fox)
}
/// `NeutralMob.isAngryAt(player)`: the player the anger names, or, with the
/// `universal_anger` rule on and no anger target left, any player. Creative and
/// spectator players are dropped first (`isValidPlayerTarget`), by the goal's
/// `can_target_player`.
pub(super) fn angry_at_player(m: &Mob, w: &MobWorld) -> bool {
    m.extra.angry_at == Some(Who::Player)
        || (w.universal_anger && m.extra.anger > 0 && m.extra.angry_at.is_none())
}
/// `Wolf.isAngry`.
pub fn angry(m: &Mob) -> bool {
    m.extra.anger > 0
}
/// `TamableAnimal.applyTamingSideEffects` for wolves: 40 health when tame.
pub fn set_tame(m: &mut Mob, tame: bool) {
    m.extra.tame = tame;
    if tame {
        m.attrs.max_health = 40.0;
        m.health = 40.0;
    } else {
        m.attrs.max_health = 8.0;
    }
    // `setBaseValue`: a base kept from the load or `/attribute` is replaced too.
    let base = wolf_health_base(tame);
    if m.species() == Species::Wolf
        && let Some(b) = m.extra.attributes.as_mut().and_then(|s| {
            s.bases
                .iter_mut()
                .find(|(a, _)| *a == super::finalize::Attr::MaxHealth)
        })
    {
        b.1 = base;
    }
}
/// The max_health base `Wolf.applyTamingSideEffects` sets.
pub fn wolf_health_base(tame: bool) -> f64 {
    if tame { 40.0 } else { 8.0 }
}
/// `TamableAnimal.getOwner`: the player the saved owner UUID names, when it
/// is the one this mob sees; anyone else nearby is not its owner.
fn owner_view<'a>(m: &Mob, w: &'a MobWorld) -> Option<&'a PlayerView> {
    if !m.extra.tame {
        return None;
    }
    let p = w.selected_player()?;
    (m.extra.owner == Some(p.uuid)).then_some(p)
}
/// The owner's position, eye height and spectator flag when tame.
fn owner(m: &Mob, w: &MobWorld) -> Option<(Vec3, f64, bool)> {
    let p = owner_view(m, w)?;
    Some((p.position, p.eye[1], p.spectator))
}
/// Whether the player the mob sees is the one saved as its owner (with
/// guests on, that player is whoever stands nearest).
fn is_owner(m: &Mob, w: &MobWorld) -> bool {
    w.selected_player()
        .is_some_and(|p| owned_by(m.extra.owner, p.uuid))
}
/// Whether `uuid` is the saved owner. A host with no UUID yet owns what it
/// tamed under the placeholder `[0, 0, 0, 1]`.
pub fn owned_by(owner: Option<[i32; 4]>, uuid: [i32; 4]) -> bool {
    owner.is_some_and(|o| o == uuid || (o == [0, 0, 0, 1] && uuid == [0; 4]))
}
/// `TamableAnimal.unableToMoveToOwner`: ordered to sit, riding something
/// (`isPassenger`), on a lead or holding one's data until it is found after
/// loading (`mayBeLeashed`), or an owner who is a spectator.
fn unable_to_move_to_owner(m: &Mob, w: &MobWorld) -> bool {
    m.extra.sitting
        || m.extra.passenger
        || m.extra.leash.is_some()
        || m.extra.leash_pending.is_some()
        || owner_view(m, w).is_some_and(|p| p.spectator)
}
/// `TamableAnimal.tryToTeleportToOwner`: ten tries around the owner.
fn teleport_to_owner(m: &mut Mob, w: &MobWorld) {
    let Some((at, _, _)) = owner(m, w) else {
        return;
    };
    let base = [
        at.x.floor() as i32,
        at.y.floor() as i32,
        at.z.floor() as i32,
    ];
    for _ in 0..10 {
        let xd = m.random.next_int_bound(7).unwrap_or(0) - 3;
        let zd = m.random.next_int_bound(7).unwrap_or(0) - 3;
        if xd.abs() < 2 && zd.abs() < 2 {
            continue;
        }
        let yd = m.random.next_int_bound(3).unwrap_or(0) - 1;
        let p = [base[0] + xd, base[1] + yd, base[2] + zd];
        if can_teleport_to(m, w, p) {
            m.position = Vec3::new(
                f64::from(p[0]) + 0.5,
                f64::from(p[1]),
                f64::from(p[2]) + 0.5,
            );
            m.previous = m.position;
            m.nav_stop();
            return;
        }
    }
}
/// `TamableAnimal.canTeleportTo`: walkable, not on leaves (unless it can
/// fly, `Parrot.canFlyToOwner`), no collision.
fn can_teleport_to(m: &Mob, w: &MobWorld, p: [i32; 3]) -> bool {
    let below = w.facts.get(w.world.block(p[0], p[1] - 1, p[2]));
    let flies = m.species() == Species::Parrot;
    if !below.full_collision || (!flies && below.name.ends_with("_leaves")) {
        return false;
    }
    let here = w.facts.get(w.world.block(p[0], p[1], p[2]));
    if here.fluid != crate::blocks::Fluid::None {
        return false;
    }
    let half = f64::from(m.width()) / 2.0;
    let (x, y, z) = (
        f64::from(p[0]) + 0.5,
        f64::from(p[1]),
        f64::from(p[2]) + 0.5,
    );
    w.no_collision(Aabb::new(
        Vec3::new(x - half, y, z - half),
        Vec3::new(x + half, y + f64::from(m.height()), z + half),
    ))
}
fn owner_distance_sqr(m: &Mob, w: &MobWorld) -> Option<f64> {
    owner(m, w).map(|(at, _, _)| m.distance_sqr(at))
}

/// `TamableAnimal.TamableAnimalPanicGoal`: the wrapped `PanicGoal` is built
/// with the damage tag its species fears (`#panic_environmental_causes` for a
/// wolf, the default `#panic_causes` for a cat or parrot), and a panic
/// teleports a pet to a far owner.
#[derive(Clone, Debug)]
struct TamePanic(Panic);
impl Goal for TamePanic {
    goal_clone!();
    fn flags(&self) -> u8 {
        self.0.flags()
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        self.0.can_use(m, cx)
    }
    fn can_continue(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        self.0.can_continue(m, cx)
    }
    fn start(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.0.start(m, cx)
    }
    fn stop(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.0.stop(m, cx)
    }
    fn tick(&mut self, m: &mut Mob, cx: &mut Cx) {
        if !unable_to_move_to_owner(m, cx.w)
            && owner_distance_sqr(m, cx.w).is_some_and(|d| d >= 144.0)
        {
            teleport_to_owner(m, cx.w);
        }
        self.0.tick(m, cx);
    }
}
/// `SitWhenOrderedToGoal`.
#[derive(Clone, Debug)]
struct SitWhenOrdered;
impl Goal for SitWhenOrdered {
    goal_clone!();
    fn flags(&self) -> u8 {
        JUMP | MOVE
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        if !m.extra.sitting && !m.extra.tame {
            return false;
        }
        if m.fluids.in_water || !m.on_ground {
            return false;
        }
        match owner_distance_sqr(m, cx.w) {
            None => true,
            Some(d) => {
                let attacked = owner_view(m, cx.w).is_some_and(|p| p.hurt_by.is_some());
                !(d < 144.0 && attacked) && m.extra.sitting
            }
        }
    }
    fn can_continue(&mut self, m: &mut Mob, _: &mut Cx) -> bool {
        m.extra.sitting
    }
    /// `SitWhenOrderedToGoal.start`: stop and sit. A wolf's begging tilt is
    /// `BegGoal`'s to end, and a cat lying down gets up when its relax goal
    /// stops.
    fn start(&mut self, m: &mut Mob, _: &mut Cx) {
        m.nav_stop();
    }
}
/// `Wolf.WolfAvoidEntityGoal`: untamed wolves flee llamas.
#[derive(Clone, Debug)]
struct AvoidLlamas(super::goals::AvoidEntity);
impl AvoidLlamas {
    fn new() -> Self {
        Self(super::goals::AvoidEntity::new(
            super::goals::Avoid::Species(vec![Species::Llama, Species::TraderLlama]),
            24.0,
            1.5,
            1.5,
        ))
    }
}
/// `Wolf.WolfAvoidEntityGoal`: a wild wolf runs from a llama, the more
/// likely the stronger it is (`strength >= random.nextInt(5)`), and drops
/// its target while it does.
impl Goal for AvoidLlamas {
    goal_clone!();
    fn name(&self) -> &'static str {
        "WolfAvoidEntityGoal"
    }
    fn flags(&self) -> u8 {
        self.0.flags()
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        if !self.0.can_use(m, cx) {
            return false;
        }
        // Seen.secondary_variant is the llama's strength (`variant2`).
        let Some(strength) = self
            .0
            .found
            .and_then(|id| cx.w.seen(id))
            .map(|s| s.secondary_variant)
        else {
            return false;
        };
        !m.extra.tame && i32::from(strength) >= m.random.next_int_bound(5).unwrap_or(0)
    }
    fn can_continue(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        self.0.can_continue(m, cx)
    }
    fn start(&mut self, m: &mut Mob, cx: &mut Cx) {
        m.set_ai_target(cx.w, None);
        self.0.start(m, cx)
    }
    fn stop(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.0.stop(m, cx)
    }
    fn tick(&mut self, m: &mut Mob, cx: &mut Cx) {
        m.set_ai_target(cx.w, None);
        self.0.tick(m, cx)
    }
}
/// `FollowOwnerGoal(speed, startDistance, stopDistance)`.
#[derive(Clone, Debug)]
struct FollowOwner {
    speed: f64,
    start: f64,
    stop: f64,
    recalc: i32,
}
impl FollowOwner {
    fn new(speed: f64, start: f64, stop: f64) -> Self {
        Self {
            speed,
            start,
            stop,
            recalc: 0,
        }
    }
}
impl Goal for FollowOwner {
    goal_clone!();
    fn flags(&self) -> u8 {
        MOVE | LOOK
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        let Some(d) = owner_distance_sqr(m, cx.w) else {
            return false;
        };
        !unable_to_move_to_owner(m, cx.w) && d >= self.start * self.start
    }
    fn can_continue(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        if m.ai.nav.is_done() || unable_to_move_to_owner(m, cx.w) {
            return false;
        }
        owner_distance_sqr(m, cx.w).is_some_and(|d| d > self.stop * self.stop)
    }
    fn start(&mut self, m: &mut Mob, _: &mut Cx) {
        self.recalc = 0;
        m.set_malus(super::path::PathType::Water, 0.0);
    }
    fn stop(&mut self, m: &mut Mob, _: &mut Cx) {
        m.nav_stop();
        let water = super::path::PathType::Water.malus();
        m.set_malus(super::path::PathType::Water, water);
    }
    fn every_tick(&self) -> bool {
        true
    }
    fn tick(&mut self, m: &mut Mob, cx: &mut Cx) {
        let Some((at, eye, _)) = owner(m, cx.w) else {
            return;
        };
        let far = m.distance_sqr(at) >= 144.0;
        if !far {
            let max = m.max_head_x_rot();
            m.look_at_speed([at.x, eye, at.z], 10.0, max);
        }
        self.recalc -= 1;
        if self.recalc <= 0 {
            self.recalc = reduced(10);
            if far {
                teleport_to_owner(m, cx.w);
            } else {
                m.nav_move_to_entity(cx.w, [at.x, at.y, at.z], 0, self.speed);
            }
        }
    }
}
/// `OwnerHurtByTargetGoal`: attack what hurt the owner.
#[derive(Clone, Debug)]
struct OwnerHurtBy {
    timestamp: i64,
}
impl Goal for OwnerHurtBy {
    goal_clone!();
    fn flags(&self) -> u8 {
        TARGET
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        if !m.extra.tame || m.extra.sitting {
            return false;
        }
        let Some((who, at)) = owner_view(m, cx.w).and_then(|p| p.hurt_by) else {
            return false;
        };
        at != self.timestamp && wants_to_attack(m, cx.w, who)
    }
    fn can_continue(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        m.ai.target
            .and_then(|t| cx.w.target_info(t))
            .is_some_and(|t| t.alive)
    }
    fn start(&mut self, m: &mut Mob, cx: &mut Cx) {
        if let Some((who, at)) = owner_view(m, cx.w).and_then(|p| p.hurt_by) {
            m.set_ai_target(cx.w, Some(who));
            self.timestamp = at;
        }
    }
    fn stop(&mut self, m: &mut Mob, cx: &mut Cx) {
        m.set_ai_target(cx.w, None);
    }
}
/// `OwnerHurtTargetGoal`: attack what the owner attacks.
#[derive(Clone, Debug)]
struct OwnerHurt {
    timestamp: i64,
}
impl Goal for OwnerHurt {
    goal_clone!();
    fn flags(&self) -> u8 {
        TARGET
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        if !m.extra.tame || m.extra.sitting {
            return false;
        }
        let Some((who, at)) = owner_view(m, cx.w).and_then(|p| p.last_hurt) else {
            return false;
        };
        at != self.timestamp && wants_to_attack(m, cx.w, who)
    }
    fn can_continue(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        m.ai.target
            .and_then(|t| cx.w.target_info(t))
            .is_some_and(|t| t.alive)
    }
    fn start(&mut self, m: &mut Mob, cx: &mut Cx) {
        if let Some((who, at)) = owner_view(m, cx.w).and_then(|p| p.last_hurt) {
            m.set_ai_target(cx.w, Some(who));
            self.timestamp = at;
        }
    }
    fn stop(&mut self, m: &mut Mob, cx: &mut Cx) {
        m.set_ai_target(cx.w, None);
    }
}
/// `Wolf.wantsToAttack`: never creepers, ghasts, tame cats and parrots, or a
/// tame wolf of the same owner.
fn wants_to_attack(m: &Mob, w: &MobWorld, who: Who) -> bool {
    let Who::Mob(id) = who else {
        return false;
    };
    if id == m.id {
        return false;
    }
    let Some(s) = w.seen(id) else {
        return false;
    };
    match s.species {
        Species::Creeper | Species::Ghast => false,
        Species::Wolf => !s.tame || s.owner != m.extra.owner,
        Species::Cat | Species::Parrot => !s.tame,
        Species::Horse | Species::Donkey | Species::Mule | Species::Llama => !s.tame,
        _ => true,
    }
}
/// `BegGoal`: tilt the head at a player holding something interesting.
#[derive(Clone, Debug)]
struct Beg {
    food: std::sync::Arc<[String]>,
    ticks: i32,
}
impl Beg {
    fn interesting(&self, w: &MobWorld) -> bool {
        let Some(p) = w.selected_player() else {
            return false;
        };
        let held = |i: &Option<std::sync::Arc<str>>| {
            // `BegGoal.playerHoldingInteresting`: a bone or food, tame or not.
            i.as_deref()
                .is_some_and(|i| i == "minecraft:bone" || self.food.iter().any(|f| f == i))
        };
        p.alive && (held(&p.main_hand) || held(&p.off_hand))
    }
}
impl Goal for Beg {
    goal_clone!();
    fn flags(&self) -> u8 {
        LOOK
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        cx.w.selected_player()
            .is_some_and(|p| p.alive && !p.spectator && m.distance_sqr(p.position) <= 64.0)
            && self.interesting(cx.w)
    }
    fn can_continue(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        cx.w.selected_player()
            .is_some_and(|p| p.alive && m.distance_sqr(p.position) <= 64.0)
            && self.ticks > 0
            && self.interesting(cx.w)
    }
    fn start(&mut self, m: &mut Mob, _: &mut Cx) {
        m.extra.flag = true;
        self.ticks = reduced(40 + m.random.next_int_bound(40).unwrap_or(0));
    }
    fn stop(&mut self, m: &mut Mob, _: &mut Cx) {
        m.extra.flag = false;
    }
    fn tick(&mut self, m: &mut Mob, cx: &mut Cx) {
        if let Some(p) = cx.w.selected_player() {
            let max = m.max_head_x_rot();
            m.look_at_speed([p.position.x, p.eye[1], p.position.z], 10.0, max);
        }
        self.ticks -= 1;
    }
}
/// `NeutralMob.isValidPlayerTarget`: a player in survival or adventure, off
/// peaceful.
fn valid_player_target(w: &MobWorld) -> bool {
    w.selected_player()
        .is_some_and(|p| !p.creative && !p.spectator)
        && w.difficulty.id != 0
}
/// `NeutralMob.stopBeingAngry`.
fn stop_being_angry(m: &mut Mob) {
    stop_being_angry_with_world(m, None);
}

fn stop_being_angry_with_world(m: &mut Mob, world: Option<&MobWorld>) {
    // setLastHurtByMob(null) also stamps the time.
    m.ai.last_hurt_by = None;
    m.ai.last_hurt_by_time = m.age as i32;
    if let Some(world) = world {
        m.set_ai_target(world, None);
    } else {
        m.ai.target = None;
    }
    m.extra.angry_at = None;
    super::neutral_anger::stop(m);
}
/// `NeutralMob.playerDied`: the anger at the player who died ends.
pub fn forgive_dead_player(m: &mut Mob) {
    if m.extra.angry_at == Some(Who::Player) {
        stop_being_angry(m);
    }
}
/// `NeutralMob.updatePersistentAnger(level, true)` from `Wolf.aiStep` and
/// `IronGolem.aiStep`: any target (the attacker, a pack-mate's attacker the
/// `HurtByTargetGoal` alert gave it, prey, the owner's enemy, a golem's
/// monster) is the anger's target, and the 20 to 39 seconds of
/// `PERSISTENT_ANGER_TIME` (the same for both) start over every tick it is held.
/// Without a target the anger runs out (`extra.anger` counts down to the end
/// time), and anger at a mob ends when that mob dies.
pub(super) fn update_persistent_anger(m: &mut Mob, w: &MobWorld) {
    let angry_at = m.extra.angry_at;
    if let Some(target @ Who::Mob(id)) = m.ai.target
        && w.seen(id).is_none_or(|s| !s.alive)
        && angry_at == Some(target)
    {
        stop_being_angry_with_world(m, Some(w));
        return;
    }
    // Mob.getTarget: a player in creative or spectator mode is no target.
    let target = m.ai.target.filter(|t| {
        *t != Who::Player
            || w.selected_player()
                .is_some_and(|p| !p.creative && !p.spectator)
    });
    if let Some(target) = target {
        m.extra.angry_at = Some(target);
        // Wolf.startPersistentAngerTimer: TimeUtil.rangeOfSeconds(20, 39).
        m.extra.anger = 400 + m.random.next_int_bound(381).unwrap_or(0);
    } else if m.extra.anger > 0 {
        m.extra.anger -= 1;
    }
    if angry_at.is_some()
        && m.extra.anger == 0
        && !(target == Some(Who::Player) && valid_player_target(w))
    {
        stop_being_angry_with_world(m, Some(w));
    }
    // The anger's target as it was when the tick began, once it is found: a
    // player who is not here yet (a reloaded wolf ticks before the player
    // joins) keeps the anger.
    if angry_at == Some(Who::Player)
        && w.selected_player()
            .is_some_and(|p| p.creative || p.spectator || w.difficulty.id == 0)
    {
        stop_being_angry_with_world(m, Some(w));
    }
}
/// The part of `Wolf.tick` both sides run: `interestedAngle` eases toward 1
/// while the wolf begs (`isInterested`, `DATA_INTERESTED_ID`), toward 0
/// otherwise, for `getHeadRollAngle`.
pub fn interest_tick(m: &mut Mob) {
    let goal = if m.extra.flag { 1.0 } else { 0.0 };
    m.anim.vo[INTEREST] = m.anim.v[INTEREST];
    m.anim.v[INTEREST] += (goal - m.anim.v[INTEREST]) * 0.4;
}
/// `Wolf.tick` / `aiStep`: anger, begging tilt and shaking off water.
pub fn ai_step(m: &mut Mob, w: &MobWorld, events: &mut Vec<MobEvent>) {
    update_persistent_anger(m, w);
    if !m.alive() {
        return;
    }
    interest_tick(m);
    // isWet (extra.flag2), isShaking (counter2 > 0).
    let wet = m.fluids.in_water || super::ai::in_rain(m, w);
    server_shake(m, wet, events);
}
/// A server's wolf: `Wolf.aiStep` starts shaking a wet wolf that stands on
/// the ground and is not pathing, and tells the clients (entity event 8),
/// then `Wolf.tick` runs the shake (`shake_tick`). `wet` is
/// `isInWaterOrRain`.
pub fn server_shake(m: &mut Mob, wet: bool, events: &mut Vec<MobEvent>) {
    if m.extra.flag2 && m.extra.counter2 == 0 && m.ai.nav.is_done() && m.on_ground {
        start_shaking(m);
        broadcast(m, events, 8);
    }
    shake_tick(m, wet, true, events);
}
/// `Wolf.tick` for a wolf of a server (`rain` is `isInRain` at the wolf):
/// a client knows it is wet on its own, starts and cancels the shake from
/// the server's entity events (`entity_event`) and draws the splashes.
pub fn client_tick(m: &mut Mob, rain: bool, events: &mut Vec<MobEvent>) {
    if m.alive() {
        shake_tick(m, m.fluids.in_water || rain, false, events);
    }
}
/// `Entity.isInRain`, for a client's wolves.
pub fn in_rain(m: &Mob, w: &MobWorld) -> bool {
    super::ai::in_rain(m, w)
}
/// `Wolf.handleEntityEvent`: 8 starts the shake, 56 cancels it.
pub fn entity_event(m: &mut Mob, event: u8) {
    match event {
        8 => start_shaking(m),
        56 => cancel_shake(m),
        _ => {}
    }
}
/// `isShaking = true`, `shakeAnim` and `shakeAnimO` from 0.
fn start_shaking(m: &mut Mob) {
    m.extra.counter2 = 1;
    m.anim.v[SHAKE] = 0.0;
    m.anim.vo[SHAKE] = 0.0;
}
/// `Wolf.die`: the wet and shake state is cleared before the rest of the
/// death, so a wolf killed mid-shake does not shake on the ground.
pub fn die(m: &mut Mob) {
    m.extra.flag2 = false;
    cancel_shake(m);
}
/// `Wolf.cancelShake`: it stays wet.
fn cancel_shake(m: &mut Mob) {
    m.extra.counter2 = 0;
    m.anim.v[SHAKE] = 0.0;
    m.anim.vo[SHAKE] = 0.0;
}
fn broadcast(m: &Mob, events: &mut Vec<MobEvent>, event: i8) {
    events.push(MobEvent::EntityEvent {
        mob: m.id,
        event,
        at: [m.position.x, m.position.y, m.position.z],
    });
}
/// The wet and shaking part of `Wolf.tick`. In water or rain the wolf is
/// wet, and a server cancels its shake (entity event 56). Out of it a
/// shaking wolf shakes for 2 (`shakeAnim` by 0.05 a tick), dry at the end,
/// with splashes past 0.4 (drawn by a client). The sound is the server's:
/// `Entity.playSound` plays nothing on a client (`ClientLevel.playSound`
/// with no player).
fn shake_tick(m: &mut Mob, wet: bool, server: bool, events: &mut Vec<MobEvent>) {
    let shaking = m.extra.counter2 > 0;
    if wet {
        m.extra.flag2 = true;
        if shaking && server {
            broadcast(m, events, 56);
            cancel_shake(m);
        }
    } else if shaking {
        if m.anim.v[SHAKE] == 0.0 {
            let pitch = (m.random.next_float() - m.random.next_float()) * 0.2 + 1.0;
            if server {
                events.push(MobEvent::Sound("entity.wolf.shake", m.center(), 0.4, pitch));
                // Wolf.tick: `gameEvent(GameEvent.ENTITY_ACTION)` with the sound (a client's
                // level hears no game events).
                events.push(MobEvent::GameEvent {
                    event: "minecraft:entity_action",
                    at: [m.position.x, m.position.y, m.position.z],
                    source: m.id,
                    state: horizon_world::registry::BlockStateId(0),
                });
            }
        }
        m.anim.vo[SHAKE] = m.anim.v[SHAKE];
        m.anim.v[SHAKE] += 0.05;
        if m.anim.vo[SHAKE] >= 2.0 {
            m.extra.flag2 = false;
            cancel_shake(m);
        }
        if m.anim.v[SHAKE] > 0.4 {
            // The server draws the offsets too (its addParticle draws nothing).
            let y = m.position.y as f32 + 0.8;
            let count = (((m.anim.v[SHAKE] - 0.4) * PI).msin() * 7.0) as i32;
            let half = m.width() * 0.5;
            let v = m.velocity;
            for _ in 0..count {
                let dx = (m.random.next_float() * 2.0 - 1.0) * half;
                let dz = (m.random.next_float() * 2.0 - 1.0) * half;
                events.push(MobEvent::ParticleAt {
                    kind: "splash",
                    at: [
                        m.position.x + f64::from(dx),
                        f64::from(y),
                        m.position.z + f64::from(dz),
                    ],
                    velocity: [v.x, v.y, v.z],
                });
            }
        }
    }
}
/// `Wolf.hurtServer`, `Parrot.hurtServer`: `setOrderedToSit(false)`. A
/// wolf's anger comes with the target (`HurtByTargetGoal`, then
/// `updatePersistentAnger`).
pub fn stand_when_hurt(m: &mut Mob) {
    m.extra.sitting = false;
}
/// `Wolf.getTailAngle`.
fn tail_angle(m: &Mob) -> f32 {
    if angry(m) {
        1.539_380_4
    } else if m.extra.tame {
        let max = m.attrs.max_health;
        let ratio = (max - m.health) / max;
        (0.55 - ratio * 0.4) * PI
    } else {
        PI / 5.0
    }
}
/// `WolfRenderState.getBodyRollAngle`.
fn body_roll(shake: f32, offset: f32) -> f32 {
    let p = ((shake + offset) / 1.8).clamp(0.0, 1.0);
    (p * PI).msin() * (p * PI * 11.0).msin() * 0.15 * PI
}
/// `WolfModel.setupAnim` with the adult and baby overrides.
pub fn anim(m: &Mob, s: &State, p: &mut Poses) {
    let (pos, speed) = (s.pos, s.speed);
    let baby = m.is_baby();
    if angry(m) {
        p.yrot("tail", 0.0);
    } else {
        p.yrot("tail", (pos * 0.6662).mcos() * 1.4 * speed);
    }
    if m.extra.sitting {
        let age = if baby { 0.5 } else { 1.0 };
        let add = |p: &mut Poses, part: &str, x: f32, y: f32, z: f32| {
            let v = p.get(part);
            v[0] += x;
            v[1] += y;
            v[2] += z;
        };
        add(p, "body", 0.0, 4.0 * age, -2.0 * age);
        p.xrot("body", PI / 4.0);
        add(p, "tail", 0.0, 9.0 * age, -2.0 * age);
        add(p, "right_hind_leg", 0.0, 6.7 * age, -5.0 * age);
        p.xrot("right_hind_leg", PI * 3.0 / 2.0);
        add(p, "left_hind_leg", 0.0, 6.7 * age, -5.0 * age);
        p.xrot("left_hind_leg", PI * 3.0 / 2.0);
        p.xrot("right_front_leg", 5.811_947);
        add(p, "right_front_leg", 0.01 * age, 1.0 * age, 0.0);
        p.xrot("left_front_leg", 5.811_947);
        add(p, "left_front_leg", -0.01 * age, 1.0 * age, 0.0);
        if baby {
            let x = p.get("body")[3] - PI / 2.0;
            p.xrot("body", x);
        } else if p.has("upper_body") {
            p.get("upper_body")[1] += 2.0;
            p.xrot("upper_body", PI * 2.0 / 5.0);
            p.yrot("upper_body", 0.0);
        }
    } else {
        p.xrot("right_hind_leg", (pos * 0.6662).mcos() * 1.4 * speed);
        p.xrot("left_hind_leg", (pos * 0.6662 + PI).mcos() * 1.4 * speed);
        p.xrot("right_front_leg", (pos * 0.6662 + PI).mcos() * 1.4 * speed);
        p.xrot("left_front_leg", (pos * 0.6662).mcos() * 1.4 * speed);
    }
    // shakeOffWater
    let shake = m.anim.lerp(SHAKE, s.partial);
    let roll = m.anim.lerp(INTEREST, s.partial) * 0.15 * PI;
    p.zrot("body", body_roll(shake, -0.16));
    if baby {
        p.zrot("head", roll + body_roll(shake, 0.0));
        p.zrot("tail", body_roll(shake, -0.2));
    } else {
        if p.has("real_head") {
            p.zrot("real_head", roll + body_roll(shake, 0.0));
        }
        if p.has("upper_body") {
            p.zrot("upper_body", body_roll(shake, -0.08));
        }
        if p.has("real_tail") {
            p.zrot("real_tail", body_roll(shake, -0.2));
        }
    }
    p.xrot("head", s.x_rot.to_radians());
    p.yrot("head", s.y_rot.to_radians());
    p.xrot("tail", tail_angle(m));
}
/// `Wolf.getWetShade` as a vertex colour.
pub fn tint(m: &Mob, partial: f32) -> u32 {
    if !m.extra.flag2 {
        return 0xFFFF_FFFF;
    }
    let shade = (0.75 + m.anim.lerp(SHAKE, partial) / 2.0 * 0.25).min(1.0);
    let c = (shade * 255.0) as u32;
    0xFF00_0000 | c << 16 | c << 8 | c
}
/// `Wolf.getTexture`.
pub fn texture(m: &Mob) -> String {
    let file = WOLF_VARIANTS[(m.extra.variant as usize).min(8)].1;
    let state = if m.extra.tame {
        "_tame"
    } else if angry(m) {
        "_angry"
    } else {
        ""
    };
    let baby = if m.is_baby() { "_baby" } else { "" };
    format!("entity/wolf/{file}{state}{baby}")
}

/// Cat variants (`CatVariants`): registry name, texture file.
pub const CAT_VARIANTS: [&str; 11] = [
    "tabby",
    "black",
    "red",
    "siamese",
    "british_shorthair",
    "calico",
    "persian",
    "ragdoll",
    "white",
    "jellie",
    "all_black",
];
// Cat AnimState slots.
const LIE: usize = 0;
const LIE_TAIL: usize = 1;
const RELAX: usize = 2;

/// `Cat.registerGoals` (with `reassessTameGoals`' player avoidance).
pub fn register_cat(m: &mut Mob) {
    m.extra.color = RED;
    let food = m.kind.food.clone();
    let g = &mut m.ai.goals;
    g.add(1, Float);
    g.add(1, TamePanic(Panic::new(1.5)));
    g.add(2, SitWhenOrdered);
    g.add(3, CatRelaxOnOwner::default());
    g.add(4, CatTempt(super::goals::Tempt::new(0.6, food, true), None));
    g.add(
        5,
        CatLieOnBlock(super::goals::MoveToBlock {
            vertical_start: -2,
            ..super::goals::MoveToBlock::new(1.1, 8, 6)
        }),
    );
    g.add(6, FollowOwner::new(1.0, 10.0, 5.0));
    g.add(7, CatSitOnBlock(super::goals::MoveToBlock::new(0.8, 8, 1)));
    g.add(8, LeapAtTarget::new(0.3));
    g.add(9, OcelotAttack { attack_time: 0 });
    g.add(10, Breed::new(0.8));
    g.add(11, Stroll::avoiding_water(0.8));
    g.add(12, LookAtPlayer::new(10.0));
    // `reassessTameGoals` adds the avoidance after `registerGoals`: goals run
    // in insertion order, so it comes last.
    g.add(
        4,
        super::goals::AvoidEntity::new(super::goals::Avoid::Player, 16.0, 0.8, 1.33)
            .when(|m| !m.extra.tame),
    );
    m.ai.targets.add(
        1,
        NonTameTarget::new(NearestTarget::species(&[Species::Rabbit], false)),
    );
    m.ai.targets.add(
        1,
        NonTameTarget::new(NearestTarget::new(Prey::Filter(baby_turtle_on_land), false)),
    );
}
/// `Ocelot.registerGoals`, then `reassessTrustingGoals` adds the player
/// avoidance last. A trusting ocelot (`Ocelot.mobInteract`, the `Trusting`
/// tag) neither runs from players nor is scared off while tempted.
pub fn register_ocelot(m: &mut Mob) {
    let food = m.kind.food.clone();
    let mut stroll = Stroll::avoiding_water(0.8);
    stroll.water_avoiding = Some(1.000_000_1e-5);
    let g = &mut m.ai.goals;
    g.add(1, Float);
    g.add(3, OcelotTempt(super::goals::Tempt::new(0.6, food, true)));
    g.add(7, LeapAtTarget::new(0.3));
    g.add(8, OcelotAttack { attack_time: 0 });
    g.add(9, Breed::new(0.8));
    g.add(10, stroll);
    g.add(11, LookAtPlayer::new(10.0));
    g.add(4, OcelotAvoid::new());
    m.ai.targets
        .add(1, NearestTarget::species(&[Species::Chicken], false));
    m.ai.targets.add(
        1,
        NearestTarget::new(Prey::Filter(baby_turtle_on_land), false),
    );
}
/// `Ocelot.OcelotTemptGoal(ocelot, 0.6, ocelot food, true)`.
#[derive(Clone, Debug)]
struct OcelotTempt(super::goals::Tempt);
impl Goal for OcelotTempt {
    goal_clone!();
    fn name(&self) -> &'static str {
        "OcelotTemptGoal"
    }
    fn flags(&self) -> u8 {
        self.0.flags()
    }
    // `OcelotTemptGoal.canScare`: `super.canScare() && !isTrusting()`.
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        self.scared_unless_trusting(m, |t, m| t.can_use(m, cx))
    }
    fn can_continue(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        self.scared_unless_trusting(m, |t, m| t.can_continue(m, cx))
    }
    fn start(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.0.start(m, cx)
    }
    fn stop(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.0.stop(m, cx)
    }
    fn every_tick(&self) -> bool {
        self.0.every_tick()
    }
    fn tick(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.scared_unless_trusting(m, |t, m| t.tick(m, cx))
    }
}
impl OcelotTempt {
    /// Runs `f` with the tempt goal's `can_scare` off for a trusting ocelot.
    fn scared_unless_trusting<R>(
        &mut self,
        m: &mut Mob,
        f: impl FnOnce(&mut super::goals::Tempt, &mut Mob) -> R,
    ) -> R {
        let scare = self.0.can_scare;
        self.0.can_scare = scare && !m.extra.trusting;
        let result = f(&mut self.0, m);
        self.0.can_scare = scare;
        result
    }
}
/// `Ocelot.OcelotAvoidEntityGoal(ocelot, Player.class, 16.0F, 0.8, 1.33)`.
#[derive(Clone, Debug)]
struct OcelotAvoid(super::goals::AvoidEntity);
impl OcelotAvoid {
    fn new() -> Self {
        Self(super::goals::AvoidEntity::new(
            super::goals::Avoid::Player,
            16.0,
            0.8,
            1.33,
        ))
    }
}
impl Goal for OcelotAvoid {
    goal_clone!();
    fn name(&self) -> &'static str {
        "OcelotAvoidEntityGoal"
    }
    fn flags(&self) -> u8 {
        self.0.flags()
    }
    // `OcelotAvoidEntityGoal.canUse` and `canContinueToUse`: `!isTrusting() && super`.
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        !m.extra.trusting && self.0.can_use(m, cx)
    }
    fn can_continue(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        !m.extra.trusting && self.0.can_continue(m, cx)
    }
    fn start(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.0.start(m, cx)
    }
    fn stop(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.0.stop(m, cx)
    }
    fn tick(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.0.tick(m, cx)
    }
}
/// `Cat.isInSittingPose`: ordered to sit or sitting on a block.
pub fn cat_sitting(m: &Mob) -> bool {
    m.extra.sitting || m.extra.flag2
}
/// `Cat.CatTemptGoal`: only wild cats come for fish. The second field is
/// `selectedPlayer`, the player the cat has picked to approach unscared.
#[derive(Clone, Debug)]
struct CatTempt(super::goals::Tempt, Option<[i32; 4]>);
impl Goal for CatTempt {
    goal_clone!();
    fn flags(&self) -> u8 {
        self.0.flags()
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        !m.extra.tame && self.0.can_use(m, cx)
    }
    fn can_continue(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        // `CatTemptGoal` has no `canContinueToUse`: `TemptGoal`'s calls
        // `canUse()` again, so `!isTame()` is re-checked mid-tempt.
        if m.extra.tame {
            return false;
        }
        // CatTemptGoal.canScare: a selected player that is the tempter is not scared.
        let picked = self.1.is_some() && self.1 == cx.w.selected_player().map(|p| p.uuid);
        let scare = self.0.can_scare;
        self.0.can_scare = scare && !picked;
        let go = self.0.can_continue(m, cx);
        self.0.can_scare = scare;
        go
    }
    fn start(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.0.start(m, cx)
    }
    fn stop(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.0.stop(m, cx)
    }
    fn every_tick(&self) -> bool {
        self.0.every_tick()
    }
    fn tick(&mut self, m: &mut Mob, cx: &mut Cx) {
        // Cat.tick: a wild cat being tempted begs every 100 ticks.
        if m.age.is_multiple_of(100) {
            cx.events.push(MobEvent::Sound(
                super::finalize::variant_sound(m, "beg_for_food")
                    .unwrap_or("entity.cat.beg_for_food"),
                m.center(),
                1.0,
                1.0,
            ));
        }
        self.0.tick(m, cx);
        // CatTemptGoal.tick: pick the tempting player with a 1 in 600 chance a
        // tick while none is picked, else drop the pick with a 1 in 500 chance.
        if self.1.is_none() && m.random.next_int_bound(reduced(600)).unwrap_or(1) == 0 {
            self.1 = cx.w.selected_player().map(|p| p.uuid);
        } else if m.random.next_int_bound(reduced(500)).unwrap_or(1) == 0 {
            self.1 = None;
        }
    }
}
fn has_tag(w: &MobWorld, p: [i32; 3], tag: &str) -> bool {
    let name = w.facts.get(w.world.block(p[0], p[1], p[2])).name.clone();
    w.block_tags.get(tag).is_some_and(|t| t.contains(&*name))
}
fn empty_above(w: &MobWorld, p: [i32; 3]) -> bool {
    w.facts
        .get(w.world.block(p[0], p[1] + 1, p[2]))
        .name
        .as_ref()
        == "minecraft:air"
}
/// Whether `p` is the player that owns `m` (a cat without a recorded owner
/// belongs to whoever it sees).
pub fn is_owner_of(m: &Mob, p: &super::PlayerView) -> bool {
    m.extra.owner.is_none_or(|o| o == p.uuid)
}
/// `Cat.CatRelaxOnOwnerGoal`: while the owner sleeps, the cat lies down beside
/// them, and may leave a morning gift when they wake up.
#[derive(Clone, Debug, Default)]
struct CatRelaxOnOwner {
    goal: Option<[i32; 3]>,
    on_bed_ticks: i32,
}
impl CatRelaxOnOwner {
    /// `spaceIsOccupied`: another cat lying or relaxing within two blocks.
    fn occupied(&self, m: &Mob, w: &MobWorld) -> bool {
        let Some(g) = self.goal else { return true };
        let area = Aabb::new(
            Vec3::new(
                f64::from(g[0]) - 2.0,
                f64::from(g[1]) - 2.0,
                f64::from(g[2]) - 2.0,
            ),
            Vec3::new(
                f64::from(g[0]) + 3.0,
                f64::from(g[1]) + 3.0,
                f64::from(g[2]) + 3.0,
            ),
        );
        w.others.iter().any(|o| {
            o.species == Species::Cat && o.id != m.id && o.lying && o.bounds.intersects(area)
        })
    }
    /// The owner's sleeping state, when this cat may relax on them: the
    /// player it sees has to be its owner (`Cat.getOwner`).
    fn sleeping_owner<'w>(m: &Mob, w: &'w MobWorld) -> Option<&'w super::PlayerView> {
        w.selected_player()
            .filter(|p| m.extra.tame && !m.extra.sitting && p.sleeping && is_owner_of(m, p))
    }
}
impl Goal for CatRelaxOnOwner {
    goal_clone!();
    fn flags(&self) -> u8 {
        0
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        let w = cx.w;
        let Some(p) = Self::sleeping_owner(m, w) else {
            return false;
        };
        if m.distance_sqr(p.position) > 100.0 {
            return false;
        }
        let at = [
            p.position.x.floor() as i32,
            p.position.y.floor() as i32,
            p.position.z.floor() as i32,
        ];
        if !has_tag(w, at, "minecraft:cats_can_lie_on") {
            return false;
        }
        // The bed's foot: against `BedBlock.FACING`.
        let back = match w.prop(at[0], at[1], at[2], "facing") {
            Some("north") => [0, 0, 1],
            Some("south") => [0, 0, -1],
            Some("east") => [-1, 0, 0],
            Some("west") => [1, 0, 0],
            Some("up") => [0, -1, 0],
            Some("down") => [0, 1, 0],
            _ => [0, 0, 0],
        };
        self.goal = Some([at[0] + back[0], at[1] + back[1], at[2] + back[2]]);
        !self.occupied(m, w)
    }
    fn can_continue(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        Self::sleeping_owner(m, cx.w).is_some() && self.goal.is_some() && !self.occupied(m, cx.w)
    }
    fn start(&mut self, m: &mut Mob, cx: &mut Cx) {
        if let Some(g) = self.goal {
            m.extra.flag2 = false;
            m.nav_move_to(
                cx.w,
                [f64::from(g[0]), f64::from(g[1]), f64::from(g[2])],
                1.1,
            );
        }
    }
    fn stop(&mut self, m: &mut Mob, cx: &mut Cx) {
        m.extra.flag = false;
        // The `gameplay/cat_waking_up_gift_chance` of the `day` timeline: 0.7
        // from tick 23667 of the day to tick 362 of the next, 0 in between.
        let day = cx.w.day_time.rem_euclid(24000);
        let chance =
            if cx.w.dimension_type.has_timeline("minecraft:day") && !(362..23667).contains(&day) {
                0.7
            } else {
                0.0
            };
        if cx
            .w
            .selected_player()
            .is_some_and(|p| is_owner_of(m, p) && p.sleep_timer >= 100)
            && m.random.next_float() < chance
        {
            give_morning_gift(m, cx);
        }
        self.on_bed_ticks = 0;
        m.extra.relax_one = false;
        m.nav_stop();
    }
    fn tick(&mut self, m: &mut Mob, cx: &mut Cx) {
        let (Some(p), Some(g)) = (cx.w.selected_player(), self.goal) else {
            return;
        };
        m.extra.flag2 = false;
        m.nav_move_to(
            cx.w,
            [f64::from(g[0]), f64::from(g[1]), f64::from(g[2])],
            1.1,
        );
        if m.distance_sqr(p.position) < 2.5 {
            self.on_bed_ticks += 1;
            if self.on_bed_ticks > reduced(16) {
                m.extra.flag = true;
                m.extra.relax_one = false;
            } else {
                m.look_at_speed(p.eye, 45.0, 45.0);
                m.extra.relax_one = true;
            }
        } else {
            m.extra.flag = false;
        }
    }
}
/// `CatRelaxOnOwnerGoal.giveMorningGift`: hop to a spot within five blocks
/// (`randomTeleport`, avoiding `#dangerous_for_teleportation`) and drop a
/// `gameplay/cat_morning_gift` item at its feet.
fn give_morning_gift(m: &mut Mob, cx: &mut Cx) {
    let w = cx.w;
    let at = [
        m.position.x.floor() as i32,
        m.position.y.floor() as i32,
        m.position.z.floor() as i32,
    ];
    let x = at[0] + m.random.next_int_bound(11).unwrap_or(5) - 5;
    let y = at[1] + m.random.next_int_bound(5).unwrap_or(2) - 2;
    let z = at[2] + m.random.next_int_bound(11).unwrap_or(5) - 5;
    let tagged = |p: [i32; 3], tag| has_tag(w, p, tag);
    let mut ground = y - 1;
    while ground > w.world.bottom_y()
        && !tagged([x, ground, z], "minecraft:entities_can_teleport_to")
    {
        ground -= 1;
    }
    if w.world.loaded(x, z) && ground > w.world.bottom_y() {
        let feet = f64::from(ground + 1);
        let half = f64::from(m.width()) / 2.0;
        let b = Aabb::new(
            Vec3::new(f64::from(x) - half, feet, f64::from(z) - half),
            Vec3::new(
                f64::from(x) + half,
                feet + f64::from(m.height()),
                f64::from(z) + half,
            ),
        );
        let dangerous = |p| tagged(p, "minecraft:dangerous_for_teleportation");
        let in_box = |f: &dyn Fn([i32; 3]) -> bool| {
            (b.min(Axis::X).floor() as i32..=b.max(Axis::X).floor() as i32).any(|bx| {
                (b.min(Axis::Y).floor() as i32..=b.max(Axis::Y).floor() as i32).any(|by| {
                    (b.min(Axis::Z).floor() as i32..=b.max(Axis::Z).floor() as i32)
                        .any(|bz| f([bx, by, bz]))
                })
            })
        };
        let fluids = w.fluids(b, feet);
        if !dangerous([x, ground, z])
            && w.no_collision(b)
            && !(fluids.in_water || fluids.in_lava)
            && !in_box(&dangerous)
        {
            m.position = Vec3::new(f64::from(x), feet, f64::from(z));
            m.previous = m.position;
            m.velocity = Vec3::ZERO;
        }
    }
    let yaw = m.body_yaw * (PI / 180.0);
    let here = [
        m.position.x.floor() - f64::from(yaw.msin()),
        m.position.y.floor(),
        m.position.z.floor() + f64::from(yaw.mcos()),
    ];
    cx.events.push(MobEvent::DropGift {
        table: "minecraft:gameplay/cat_morning_gift",
        at: here,
    });
}
/// `CatLieOnBlockGoal`: tame cats lie on beds and other warm blocks.
#[derive(Clone, Debug)]
struct CatLieOnBlock(super::goals::MoveToBlock);
fn can_lie_on(w: &MobWorld, p: [i32; 3]) -> bool {
    empty_above(w, p) && has_tag(w, p, "minecraft:cats_can_lie_on")
}
impl Goal for CatLieOnBlock {
    goal_clone!();
    fn flags(&self) -> u8 {
        JUMP | MOVE
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        m.extra.tame
            && !m.extra.sitting
            && !m.extra.flag
            && self.0.can_use(m, cx.w, reduced(40), can_lie_on)
    }
    fn can_continue(&mut self, _: &mut Mob, cx: &mut Cx) -> bool {
        self.0.can_continue(cx.w, can_lie_on)
    }
    fn start(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.0.start(m, cx.w);
        m.extra.flag2 = false;
    }
    fn stop(&mut self, m: &mut Mob, _: &mut Cx) {
        m.extra.flag = false;
    }
    fn every_tick(&self) -> bool {
        true
    }
    fn tick(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.0.tick(m, cx.w);
        m.extra.flag2 = false;
        m.extra.flag = self.0.reached;
    }
}
/// `CatSitOnBlockGoal`: unopened chests, lit furnaces and the foot of beds.
#[derive(Clone, Debug)]
struct CatSitOnBlock(super::goals::MoveToBlock);
fn can_sit_on(w: &MobWorld, p: [i32; 3]) -> bool {
    if !empty_above(w, p) || !has_tag(w, p, "minecraft:cats_can_sit_on") {
        return false;
    }
    let f = w.facts.get(w.world.block(p[0], p[1], p[2]));
    match f.name.as_ref() {
        // The lit state is the only light source a furnace has.
        "minecraft:furnace" => f.emission > 0,
        // `ChestBlockEntity.getOpenCount(level, pos) < 1`: players' openers
        // and the copper golems' own count.
        "minecraft:chest" => {
            let key = (p[0], p[1], p[2]);
            !w.lid_openers.contains_key(&key)
                && w.world.chest_openers.get(&key).is_none_or(|o| o.0 < 1)
        }
        // A bed's foot only (`BedBlock.PART != HEAD`).
        _ => w.prop(p[0], p[1], p[2], "part") != Some("head"),
    }
}
impl Goal for CatSitOnBlock {
    goal_clone!();
    fn flags(&self) -> u8 {
        JUMP | MOVE
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        if !m.extra.tame || m.extra.sitting {
            return false;
        }
        // MoveToBlockGoal.canUse draws the next delay only once the last one
        // has run out.
        if self.0.next_start > 0 {
            self.0.next_start -= 1;
            return false;
        }
        let next = reduced(200 + m.random.next_int_bound(200).unwrap_or(0));
        self.0.can_use(m, cx.w, next, can_sit_on)
    }
    fn can_continue(&mut self, _: &mut Mob, cx: &mut Cx) -> bool {
        self.0.can_continue(cx.w, can_sit_on)
    }
    fn start(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.0.start(m, cx.w);
        m.extra.flag2 = false;
    }
    fn stop(&mut self, m: &mut Mob, _: &mut Cx) {
        m.extra.flag2 = false;
    }
    fn every_tick(&self) -> bool {
        true
    }
    fn tick(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.0.tick(m, cx.w);
        m.extra.flag2 = self.0.reached;
    }
}
/// `OcelotAttackGoal`: stalk slowly, dash in, swipe every second.
#[derive(Clone, Debug)]
struct OcelotAttack {
    attack_time: i32,
}
impl Goal for OcelotAttack {
    goal_clone!();
    fn flags(&self) -> u8 {
        MOVE | LOOK
    }
    fn can_use(&mut self, m: &mut Mob, _: &mut Cx) -> bool {
        m.ai.target.is_some()
    }
    fn can_continue(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        let Some(t) = m.ai.target.and_then(|t| cx.w.target_info(t)) else {
            return false;
        };
        t.alive
            && m.distance_sqr(t.position) <= 225.0
            && (!m.ai.nav.is_done() || m.ai.target.is_some())
    }
    fn stop(&mut self, m: &mut Mob, _: &mut Cx) {
        m.nav_stop();
    }
    fn every_tick(&self) -> bool {
        true
    }
    fn tick(&mut self, m: &mut Mob, cx: &mut Cx) {
        let Some(who) = m.ai.target else {
            return;
        };
        let Some(t) = cx.w.target_info(who) else {
            return;
        };
        m.look_at_speed([t.position.x, t.eye_y, t.position.z], 30.0, 30.0);
        let reach = f64::from(m.width() * 2.0);
        let melee = reach * reach;
        let d2 = m.distance_sqr(t.position);
        let speed = if d2 > melee && d2 < 16.0 {
            1.33
        } else if d2 < 225.0 {
            0.6
        } else {
            0.8
        };
        m.nav_move_to_entity(cx.w, [t.position.x, t.position.y, t.position.z], 0, speed);
        self.attack_time = (self.attack_time - 1).max(0);
        if d2 <= melee && self.attack_time <= 0 {
            self.attack_time = 20;
            super::ai::do_hurt_target(m, who, cx);
        }
    }
}
/// `Cat.tick`: lying and relaxing amounts and the purr.
pub fn cat_ai_step(m: &mut Mob, events: &mut Vec<MobEvent>) {
    cat_amounts(m);
    if (m.extra.flag || m.extra.relax_one) && m.age.is_multiple_of(5) {
        let volume = 0.6 + 0.4 * (m.random.next_float() - m.random.next_float());
        let sound = super::finalize::variant_sound(m, "purr").unwrap_or("entity.cat.purr");
        events.push(MobEvent::Sound(sound, m.center(), volume, 1.0));
    }
}
/// The lying and relaxing amounts of `Cat.tick` (also a client's, from the
/// synched flags).
pub fn cat_amounts(m: &mut Mob) {
    let lying = m.extra.flag;
    let relaxing = m.extra.relax_one;
    let v = &mut m.anim.v;
    if lying {
        v[LIE] = (v[LIE] + 0.15).min(1.0);
        v[LIE_TAIL] = (v[LIE_TAIL] + 0.08).min(1.0);
    } else {
        v[LIE] = (v[LIE] - 0.22).max(0.0);
        v[LIE_TAIL] = (v[LIE_TAIL] - 0.13).max(0.0);
    }
    v[RELAX] = if relaxing {
        (v[RELAX] + 0.1).min(1.0)
    } else {
        (v[RELAX] - 0.13).max(0.0)
    };
}
/// `Cat.finalizeSpawn` variant: any but all-black, which a full moon allows.
pub fn cat_variant(m: &mut Mob, w_moon_full: bool) -> u8 {
    let n = if w_moon_full { 11 } else { 10 };
    m.random.next_int_bound(n).unwrap_or(0) as u8
}
pub fn cat_texture(m: &Mob) -> String {
    let v = CAT_VARIANTS[(m.extra.variant as usize).min(10)];
    let baby = if m.is_baby() { "_baby" } else { "" };
    format!("entity/cat/cat_{v}{baby}")
}
/// `CatRenderer.setupRotations`: lying cats roll onto their side.
pub fn cat_rotations(m: &Mob, partial: f32) -> glam::Mat4 {
    let lie = m.anim.lerp(LIE, partial);
    if lie <= 0.0 {
        return glam::Mat4::IDENTITY;
    }
    let on_top = if m.extra.on_sleeper { 0.15 * lie } else { 0.0 };
    glam::Mat4::from_translation(glam::Vec3::new(0.4 * lie, 0.15 * lie, 0.1 * lie))
        * glam::Mat4::from_rotation_z((90.0 * lie).to_radians())
        * glam::Mat4::from_translation(glam::Vec3::new(on_top, 0.0, 0.0))
}
/// `Cat.handleLieDown`'s `isLyingOnTopOfSleepingPlayer`: a lying cat with a
/// sleeping player within two blocks of its block (`sleepers` are their
/// bounding boxes).
pub fn cat_lying_on_sleeper(m: &mut Mob, sleepers: &[horizon_core::geometry::Aabb]) {
    m.extra.on_sleeper = false;
    if !m.extra.flag {
        return;
    }
    let (x, y, z) = (
        m.position.x.floor(),
        m.position.y.floor(),
        m.position.z.floor(),
    );
    let area = horizon_core::geometry::Aabb::new(
        Vec3::new(x - 2.0, y - 2.0, z - 2.0),
        Vec3::new(x + 3.0, y + 3.0, z + 3.0),
    );
    m.extra.on_sleeper = sleepers.iter().any(|b| b.intersects(area));
}
/// `Mth.rotLerp`: degrees-wrapping, applied by the feline models to radians.
fn rot_lerp(t: f32, from: f32, to: f32) -> f32 {
    from + t * super::living::wrap(to - from)
}
/// `FelineRenderState` values the feline models read.
#[derive(Clone, Copy, Debug, Default)]
pub struct Feline {
    pub crouching: bool,
    pub sprinting: bool,
    pub sitting: bool,
    pub lie_down: f32,
    pub lie_down_tail: f32,
    pub relax_one: f32,
}
/// `Cat.customServerAiStep` and `Ocelot.customServerAiStep`: crouch while
/// stalking (the move control's 0.6), sprint while dashing (1.33). Sprinting
/// adds `LivingEntity.SPEED_MODIFIER_SPRINTING` (`Mob::movement_speed`) to the
/// move control's tick that follows.
pub fn feline_server_ai_step(m: &mut Mob) {
    let speed = m.ai.mov.has_wanted().then_some(m.ai.mov.speed_modifier);
    m.extra.pose = if speed == Some(0.6) {
        super::sync::CROUCHING
    } else {
        super::sync::STANDING
    };
    m.extra.sprinting = speed == Some(1.33);
}
/// `AdultFelineModel` / `BabyFelineModel.setupAnim` for cats and ocelots.
pub fn cat_anim(m: &Mob, s: &State, p: &mut Poses) {
    // FelineRenderState: Entity.isCrouching (the pose) and isSprinting.
    let st = Feline {
        crouching: m.extra.pose == super::sync::CROUCHING,
        sprinting: m.extra.sprinting,
        sitting: cat_sitting(m),
        lie_down: m.anim.lerp(LIE, s.partial),
        lie_down_tail: m.anim.lerp(LIE_TAIL, s.partial),
        relax_one: m.anim.lerp(RELAX, s.partial),
    };
    feline(p, s, &st);
}
pub fn feline(p: &mut Poses, s: &State, st: &Feline) {
    let baby = s.baby;
    let age = if baby { 0.5 } else { 1.0 };
    let (crouching, sprinting, sitting) = (st.crouching, st.sprinting, st.sitting);
    let add = |p: &mut Poses, part: &str, x: f32, y: f32, z: f32| {
        let v = p.get(part);
        v[0] += x;
        v[1] += y;
        v[2] += z;
    };
    if crouching {
        add(p, "body", 0.0, age, 0.0);
        add(p, "head", 0.0, 2.0 * age, 0.0);
        add(p, "tail1", 0.0, age, 0.0);
        add(p, "tail2", 0.0, -4.0 * age, 2.0 * age);
        p.xrot("tail1", PI / 2.0);
        p.xrot("tail2", PI / 2.0);
    } else if sprinting {
        let y1 = p.get("tail1")[1];
        p.get("tail2")[1] = y1;
        add(p, "tail2", 0.0, 0.0, 2.0 * age);
        p.xrot("tail1", PI / 2.0);
        p.xrot("tail2", PI / 2.0);
    }
    p.xrot("head", s.x_rot.to_radians());
    p.yrot("head", s.y_rot.to_radians());
    let (pos, sp) = (s.pos, s.speed);
    if !sitting {
        if !baby {
            p.xrot("body", PI / 2.0);
        }
        if sprinting {
            p.xrot("left_hind_leg", (pos * 0.6662).mcos() * sp);
            p.xrot("right_hind_leg", (pos * 0.6662 + 0.3).mcos() * sp);
            p.xrot("left_front_leg", (pos * 0.6662 + PI + 0.3).mcos() * sp);
            p.xrot("right_front_leg", (pos * 0.6662 + PI).mcos() * sp);
            p.xrot("tail2", 1.727_876_1 + PI / 10.0 * pos.mcos() * sp);
        } else {
            p.xrot("left_hind_leg", (pos * 0.6662).mcos() * sp);
            p.xrot("right_hind_leg", (pos * 0.6662 + PI).mcos() * sp);
            p.xrot("left_front_leg", (pos * 0.6662 + PI).mcos() * sp);
            p.xrot("right_front_leg", (pos * 0.6662).mcos() * sp);
            let swing = if crouching { 0.471_238_94 } else { PI / 4.0 };
            p.xrot("tail2", 1.727_876_1 + swing * pos.mcos() * sp);
        }
    } else if baby {
        let x = p.get("body")[3] - 0.436_332_32;
        p.xrot("body", x);
        add(p, "body", 0.0, 1.25, 0.0);
        add(p, "head", 0.0, 0.0, 0.75);
        let t = p.get("tail1")[3] + 0.545_415_4;
        p.xrot("tail1", t);
        add(p, "tail1", 0.0, 4.0, -0.9);
        add(p, "left_hind_leg", 0.0, 0.0, -0.9);
        add(p, "right_hind_leg", 0.0, 0.0, -0.9);
    } else {
        p.xrot("body", PI / 4.0);
        add(p, "body", 0.0, -4.0 * age, 5.0 * age);
        add(p, "head", 0.0, -3.3 * age, age);
        add(p, "tail1", 0.0, 8.0 * age, -2.0 * age);
        add(p, "tail2", 0.0, 2.0 * age, -0.8 * age);
        p.xrot("tail1", 1.727_876_1);
        p.xrot("tail2", 2.670_354);
        p.xrot("left_front_leg", -PI / 20.0);
        add(p, "left_front_leg", 0.0, 2.0 * age, -2.0 * age);
        p.xrot("right_front_leg", -PI / 20.0);
        add(p, "right_front_leg", 0.0, 2.0 * age, -2.0 * age);
        p.xrot("left_hind_leg", -PI / 2.0);
        add(p, "left_hind_leg", 0.0, 3.0 * age, -4.0 * age);
        p.xrot("right_hind_leg", -PI / 2.0);
        add(p, "right_hind_leg", 0.0, 3.0 * age, -4.0 * age);
    }
    let lie = st.lie_down;
    let lie_tail = st.lie_down_tail;
    if lie > 0.0 && baby {
        add(p, "body", 1.0, 0.0, 0.0);
        let hx = p.get("head")[3];
        p.xrot("head", rot_lerp(lie, hx, PI / 18.0));
        let hz = p.get("head")[5];
        p.zrot("head", rot_lerp(lie, hz, -PI * 5.0 / 12.0));
        add(p, "head", 1.5, 0.75, -0.5);
        p.xrot("right_front_leg", -PI / 4.0);
        add(p, "right_front_leg", 3.5, -0.5, 0.0);
        p.xrot("left_front_leg", -PI / 2.0);
        add(p, "left_front_leg", 1.5, -1.0, -2.0);
        p.xrot("right_hind_leg", PI * 2.0 / 9.0);
        p.yrot("right_hind_leg", PI / 9.0);
        p.zrot("right_hind_leg", -PI / 9.0);
        add(p, "right_hind_leg", 2.5, -0.25, 0.5);
        add(p, "left_hind_leg", 1.5, 0.0, -1.0);
        let t = p.get("tail1");
        let (tx, ty, tz) = (t[3], t[4], t[5]);
        p.xrot("tail1", tx + rot_lerp(lie_tail, tx, -PI / 6.0));
        p.yrot("tail1", ty + rot_lerp(lie_tail, ty, 0.0));
        p.zrot("tail1", tz + rot_lerp(lie_tail, tz, -PI / 18.0));
        add(p, "tail1", 1.0, 0.5, -0.25);
    } else if lie > 0.0 {
        let (hz, hy) = (p.get("head")[5], p.get("head")[4]);
        p.zrot("head", rot_lerp(lie, hz, -1.270_796_3));
        p.yrot("head", rot_lerp(lie, hy, 1.270_796_3));
        p.xrot("left_front_leg", -1.270_796_3);
        p.xrot("right_front_leg", -0.470_796_35);
        p.zrot("right_front_leg", -0.2);
        add(p, "right_front_leg", age, 0.0, 0.0);
        p.xrot("left_hind_leg", -0.4);
        p.xrot("right_hind_leg", 0.5);
        p.zrot("right_hind_leg", -0.5);
        add(p, "right_hind_leg", 0.8 * age, 2.0 * age, 0.0);
        let (t1, t2) = (p.get("tail1")[3], p.get("tail2")[3]);
        p.xrot("tail1", rot_lerp(lie_tail, t1, 0.8));
        p.xrot("tail2", rot_lerp(lie_tail, t2, -0.4));
    }
    let relax = st.relax_one;
    if relax > 0.0 {
        let hx = p.get("head")[3];
        p.xrot("head", rot_lerp(relax, hx, -0.581_776_44));
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::mobs::{Damage, sensor_scan_tests::kind};
    use horizon_core::geometry::Vec3;
    use std::sync::Arc;

    /// Wolf.tick: a shake starting posts ENTITY_ACTION with its sound, on the server only.
    #[test]
    fn a_shake_posts_entity_action_on_the_server() {
        let shaking_wolf = || {
            let mut kind = kind();
            let k = Arc::make_mut(&mut kind);
            k.id = "minecraft:wolf".into();
            k.species = Species::Wolf;
            let mut m = Mob::new(1, kind, Vec3::ZERO, 0.0);
            m.extra.counter2 = 1;
            m
        };
        let action = |events: &[MobEvent]| {
            events.iter().any(|e| {
                matches!(e, MobEvent::GameEvent { event, source: 1, .. }
                    if *event == "minecraft:entity_action")
            })
        };
        let mut events = Vec::new();
        shake_tick(&mut shaking_wolf(), false, true, &mut events);
        assert!(action(&events), "the server's wolf posts entity_action");
        let mut events = Vec::new();
        shake_tick(&mut shaking_wolf(), false, false, &mut events);
        assert!(!action(&events), "a client's copy posts nothing");
    }

    /// `TamableAnimal.unableToMoveToOwner` (#12939): a pet on a lead, with lead
    /// data still to be found, or riding something neither follows nor
    /// teleports to its owner.
    #[test]
    fn a_leashed_or_riding_pet_stays_put() {
        let ran = crate::mobs::world::with_test_world(&[], |w, _| {
            let mut m = wolf();
            set_tame(&mut m, true);
            assert!(!unable_to_move_to_owner(&m, w), "a free pet follows");
            m.extra.leash = Some(super::super::leash::Holder::Knot([0, 64, 3]));
            assert!(unable_to_move_to_owner(&m, w), "tied to a fence");
            m.extra.leash = None;
            m.extra.passenger = true;
            assert!(unable_to_move_to_owner(&m, w), "in a boat");
            m.extra.passenger = false;
            m.extra.sitting = true;
            assert!(unable_to_move_to_owner(&m, w), "ordered to sit");
        });
        if !ran {
            eprintln!("skipped: no extracted vanilla data");
        }
    }
    /// `SitWhenOrderedToGoal.start` only stops and sits: a wolf begging for the
    /// bone its owner holds keeps its head tilt (`BegGoal` owns it).
    #[test]
    fn sitting_down_keeps_a_wolfs_begging_tilt() {
        let ran = crate::mobs::world::with_test_world(&[], |w, _| {
            let mut fixture = crate::health::TestLevel::new(0);
            let mut events = Vec::new();
            let mut cx = Cx {
                w,
                level: &mut fixture.level(),
                events: &mut events,
            };
            let mut m = wolf();
            set_tame(&mut m, true);
            m.extra.flag = true;
            m.extra.sitting = true;
            SitWhenOrdered.start(&mut m, &mut cx);
            assert!(m.extra.flag, "the begging tilt is BegGoal's to end");
        });
        if !ran {
            eprintln!("skipped: no extracted vanilla data");
        }
    }

    const WHITE: u32 = 0xFFFF_FFFF;

    fn cat() -> Mob {
        let mut kind = kind();
        let k = Arc::make_mut(&mut kind);
        k.id = "minecraft:cat".into();
        k.species = Species::Cat;
        Mob::new(1, kind, Vec3::new(0.5, 64.0, 0.5), 0.0)
    }
    #[test]
    fn a_cat_lying_near_a_sleeper_lies_on_top_of_them() {
        use horizon_core::geometry::Aabb;
        let sleeper = Aabb::new(Vec3::new(2.4, 64.0, 0.4), Vec3::new(2.6, 64.2, 0.6));
        let far = Aabb::new(Vec3::new(5.4, 64.0, 0.4), Vec3::new(5.6, 64.2, 0.6));
        let mut m = cat();
        m.anim.v[LIE] = 1.0;
        m.extra.flag = true;
        cat_lying_on_sleeper(&mut m, &[far]);
        assert!(!m.extra.on_sleeper);
        cat_lying_on_sleeper(&mut m, &[far, sleeper]);
        assert!(m.extra.on_sleeper);
        let on_top = cat_rotations(&m, 1.0);
        // The extra `translate(0.15 * lie, 0, 0)` after the roll.
        m.extra.on_sleeper = false;
        let plain = cat_rotations(&m, 1.0);
        assert_ne!(on_top, plain);
        assert!((on_top.w_axis.y - plain.w_axis.y - 0.15).abs() < 1.0e-4);
        // Not lying: nothing to lie on.
        m.extra.flag = false;
        cat_lying_on_sleeper(&mut m, &[sleeper]);
        assert!(!m.extra.on_sleeper);
    }
    fn wolf() -> Mob {
        let mut kind = kind();
        let k = Arc::make_mut(&mut kind);
        k.id = "minecraft:wolf".into();
        k.species = Species::Wolf;
        k.width = 0.6;
        k.height = 0.85;
        let mut m = Mob::new(1, kind, Vec3::ZERO, 0.0);
        m.on_ground = true;
        m
    }
    /// `Wolf.die`: the wet flag, the shake counter and both shake animations
    /// are cleared before any loot is rolled. The death runs
    /// `drops::death_state` first, so the reset has to be asked there, not
    /// only exist.
    #[test]
    fn a_wolf_that_dies_mid_shake_is_dry_and_still() {
        let mut m = wolf();
        // Soaked, and shaking it off: the tick sets the wet flag and entity
        // event 8 starts the shake, which counts up 0.05 a tick.
        m.extra.flag2 = true;
        entity_event(&mut m, 8);
        m.anim.v[SHAKE] = 0.9;
        m.anim.vo[SHAKE] = 0.85;
        crate::mobs::drops::death_state(&mut m);
        assert!(!m.extra.flag2, "a dead wolf is not wet");
        assert_eq!(m.extra.counter2, 0, "a dead wolf is not shaking");
        assert_eq!(m.anim.v[SHAKE], 0.0, "shakeAnim");
        assert_eq!(m.anim.vo[SHAKE], 0.0, "shakeAnimO");
    }
    fn entity_events(events: &[MobEvent]) -> Vec<i8> {
        events
            .iter()
            .filter_map(|e| match e {
                MobEvent::EntityEvent { event, .. } => Some(*event),
                _ => None,
            })
            .collect()
    }

    /// A wolf of a server (the default single player's server thread, a LAN
    /// guest): `Wolf.tick` makes it wet in water on the client too, which
    /// `getWetShade` darkens; entity event 8 starts the shake, which the
    /// client runs to the end, splashing, and then the wolf is dry (#2885).
    #[test]
    fn a_wolf_of_a_server_darkens_in_water_and_shakes_dry_on_its_event() {
        let mut m = wolf();
        let mut events = Vec::new();
        m.fluids.in_water = true;
        client_tick(&mut m, false, &mut events);
        // 0.75 of the colour: 191.
        assert_eq!(tint(&m, 1.0), 0xFFBF_BFBF, "wet in water");
        m.fluids.in_water = false;
        client_tick(&mut m, false, &mut events);
        assert_eq!(tint(&m, 1.0), 0xFFBF_BFBF, "still wet before it shakes");
        assert_eq!(m.anim.v[SHAKE], 0.0);
        // Rain wets it as well.
        let mut dry = wolf();
        client_tick(&mut dry, true, &mut events);
        assert_ne!(tint(&dry, 1.0), WHITE, "wet in the rain");

        crate::mobs::sync::entity_event(&mut m, 8);
        let mut ticks = 0;
        while m.extra.flag2 && ticks < 100 {
            client_tick(&mut m, false, &mut events);
            ticks += 1;
            if ticks == 1 {
                assert!((m.anim.v[SHAKE] - 0.05).abs() < 1e-6);
                assert_eq!(m.anim.vo[SHAKE], 0.0);
            }
        }
        // shakeAnimO reaches 2 on the 41st tick.
        assert!((41..=42).contains(&ticks), "shook for {ticks} ticks");
        assert_eq!(tint(&m, 1.0), WHITE, "dry after the shake");
        assert_eq!((m.extra.counter2, m.anim.v[SHAKE]), (0, 0.0));
        assert!(
            events
                .iter()
                .any(|e| matches!(e, MobEvent::ParticleAt { kind: "splash", .. })),
            "the client draws the splashes"
        );
        assert!(
            !events.iter().any(|e| matches!(e, MobEvent::Sound(..))),
            "the shake sound is the server's"
        );
    }

    /// `Wolf.handleEntityEvent(56)`: back in the water, the server cancels
    /// the shake; the wolf stays wet. A client does not cancel on its own.
    #[test]
    fn a_wolf_of_a_server_stops_shaking_on_its_cancel_event() {
        let mut m = wolf();
        let mut events = Vec::new();
        m.fluids.in_water = true;
        client_tick(&mut m, false, &mut events);
        m.fluids.in_water = false;
        crate::mobs::sync::entity_event(&mut m, 8);
        for _ in 0..10 {
            client_tick(&mut m, false, &mut events);
        }
        assert!(m.anim.v[SHAKE] > 0.4);
        m.fluids.in_water = true;
        client_tick(&mut m, false, &mut events);
        assert!(m.extra.counter2 > 0, "only the server cancels");
        crate::mobs::sync::entity_event(&mut m, 56);
        assert_eq!((m.extra.counter2, m.anim.v[SHAKE]), (0, 0.0));
        assert_ne!(tint(&m, 1.0), WHITE, "still wet");
    }

    /// `Wolf.aiStep` broadcasts entity event 8 when a wet wolf standing on
    /// the ground starts shaking, and `Wolf.tick` event 56 when water or rain
    /// cancels it: the clients' only way to know.
    #[test]
    fn a_server_tells_the_clients_when_a_wolf_shakes() {
        let mut m = wolf();
        let mut events = Vec::new();
        server_shake(&mut m, true, &mut events);
        assert!(m.extra.flag2);
        // Out of the water: it starts and makes its sound in the same tick.
        server_shake(&mut m, false, &mut events);
        assert_eq!(entity_events(&events), [8]);
        assert!(m.extra.counter2 > 0);
        assert!((m.anim.v[SHAKE] - 0.05).abs() < 1e-6);
        assert!(
            events
                .iter()
                .any(|e| matches!(e, MobEvent::Sound("entity.wolf.shake", ..)))
        );
        server_shake(&mut m, true, &mut events);
        assert_eq!(entity_events(&events), [8, 56]);
        assert_eq!((m.extra.counter2, m.anim.v[SHAKE]), (0, 0.0));
        assert!(m.extra.flag2, "still wet");
    }

    /// A tame mob of a species, told to sit.
    fn sitting(species: Species, name: &str) -> Mob {
        let mut kind = kind();
        let k = Arc::make_mut(&mut kind);
        k.id = name.into();
        k.species = species;
        k.max_health = 20.0;
        let mut m = Mob::new(1, kind, Vec3::new(0.0, 64.0, 0.0), 0.0);
        m.extra.tame = true;
        m.extra.sitting = true;
        m
    }

    #[test]
    fn a_hit_stands_a_sitting_wolf_or_parrot_up() {
        let mut test_level = crate::health::TestLevel::new(0);
        let level = &mut test_level.level();
        // Wolf.hurtServer and Parrot.hurtServer call setOrderedToSit(false)
        // before LivingEntity.hurtServer.
        for (species, name) in [
            (Species::Wolf, "minecraft:wolf"),
            (Species::Parrot, "minecraft:parrot"),
        ] {
            let mut m = sitting(species, name);
            assert!(m.damage(level, 1.0, Damage::player([0.0, 64.0, 1.0])));
            assert!(!m.extra.sitting, "{name} still sits after a hit");
            // A weaker hit inside the hurt frames deals nothing, but it
            // reached hurtServer, so it still stands the mob up.
            m.extra.sitting = true;
            assert!(!m.damage(level, 0.5, Damage::player([0.0, 64.0, 1.0])));
            assert!(!m.extra.sitting, "{name} still sits after a blocked hit");
        }
    }

    #[test]
    fn a_hit_leaves_a_sitting_cat_sitting() {
        let mut test_level = crate::health::TestLevel::new(0);
        let level = &mut test_level.level();
        // Cat has no hurtServer override: a hit does not stand it up.
        let mut m = sitting(Species::Cat, "minecraft:cat");
        assert!(m.damage(level, 1.0, Damage::player([0.0, 64.0, 1.0])));
        assert!(m.extra.sitting);
    }

    /// `Cat.canMate` and `Wolf.canMate`: the seeker only has to be tamed, so a
    /// mob ordered to sit still goes looking for a mate. Only a wolf's
    /// *partner* is refused while it sits (`wolf.isInSittingPose()`), which is
    /// the one sitting check vanilla makes.
    #[test]
    fn a_sitting_tame_mob_still_looks_for_a_mate() {
        use crate::mobs::goals::{Breed, Cx, Goal};
        use crate::mobs::world::with_test_world;
        let named = |species, name: &str, id: u32, sat: bool| {
            let mut m = sitting(species, name);
            m.id = id;
            m.extra.in_love = 600;
            m.extra.sitting = sat;
            m
        };
        for (species, name, seeker_sat, partner_sat, breeds) in [
            // A tamed cat pairs with a tamed cat, sitting or not.
            (Species::Cat, "minecraft:cat", true, true, true),
            (Species::Cat, "minecraft:cat", true, false, true),
            // A wolf pairs unless the wolf it would take is sitting.
            (Species::Wolf, "minecraft:wolf", true, false, true),
            (Species::Wolf, "minecraft:wolf", true, true, false),
            (Species::Wolf, "minecraft:wolf", false, true, false),
        ] {
            let mut seeker = named(species, name, 1, seeker_sat);
            let partner = named(species, name, 2, partner_sat);
            let seen = [partner.seen(None)];
            with_test_world(&seen, |w, _| {
                let mut events = Vec::new();
                let mut test_level = crate::health::TestLevel::new(0);
                let level = &mut test_level.level();
                let mut cx = Cx {
                    w,
                    level,
                    events: &mut events,
                };
                let mut goal = Breed::new(1.0);
                assert_eq!(
                    goal.can_use(&mut seeker, &mut cx),
                    breeds,
                    "{name}: seeker sits {seeker_sat}, partner sits {partner_sat}"
                );
            });
        }
    }

    /// `BegGoal` finds its player with `TargetingConditions.forNonCombat()`,
    /// which never picks a spectator or a dead player.
    #[test]
    fn a_spectator_holding_a_bone_does_not_make_a_wolf_beg() {
        use crate::mobs::goals::Cx;
        use crate::mobs::world::{test_player, with_test_world};
        let mut outcomes = Vec::new();
        if !with_test_world(&[], |w, _| {
            for spectator in [false, true] {
                let mut world = w.clone();
                let mut p = test_player(Vec3::new(2.5, 64.0, 0.5));
                p.main_hand = Some("minecraft:bone".into());
                p.spectator = spectator;
                world.player = Some(p);
                let mut kind = (*kind()).clone();
                kind.species = Species::Wolf;
                let mut m = Mob::new(1, Arc::new(kind), Vec3::new(0.5, 64.0, 0.5), 0.0);
                m.ai.goals.add(
                    1,
                    super::Beg {
                        food: Arc::from(vec!["minecraft:bone".to_string()]),
                        ticks: 0,
                    },
                );
                let mut lr = crate::health::TestLevel::new(0);
                let mut events = Vec::new();
                let mut cx = Cx {
                    w: &world,
                    level: &mut lr.level(),
                    events: &mut events,
                };
                let mut goals = std::mem::take(&mut m.ai.goals);
                goals.tick(&mut m, &mut cx);
                outcomes.push(goals.is_running("Beg"));
                m.ai.goals = goals;
            }
        }) {
            return;
        }
        assert_eq!(
            outcomes,
            vec![true, false],
            "a survival player's bone makes it beg; a spectator's does not"
        );
    }
}

/// `NeutralMob.isAngryAtAllPlayers`: with the `universal_anger` game rule on, a
/// wolf still angry with no target left goes for any player; with the rule off
/// it holds none, and a creative player is never one (`isValidPlayerTarget`).
#[cfg(test)]
mod universal_anger_tests {
    use super::*;
    use crate::mobs::world::{test_player, with_test_world};
    use std::sync::Arc;

    #[test]
    fn universal_anger_targets_a_player_the_wolf_was_never_angered_by() {
        // (the `universal_anger` rule, the player is creative, whether the wolf
        // ends up with the player as its target).
        let cases = [
            (true, false, true),
            (false, false, false),
            (true, true, false),
        ];
        with_test_world(&[], |w, types| {
            for (universal_anger, creative, targets) in cases {
                let mut w = w.clone();
                let mut p = test_player(Vec3::new(2.5, 64.0, 0.5));
                p.creative = creative;
                w.player = Some(p);
                w.universal_anger = universal_anger;
                let kind = Arc::new(types.types["minecraft:wolf"].clone());
                let mut m = Mob::new(1, kind, Vec3::new(0.5, 64.0, 0.5), 0.0);
                // `anger_end_time` still running, `angry_at` gone: angry, with
                // nobody left that it was angered by.
                m.extra.anger = 600;
                m.extra.angry_at = None;
                let mut goals = std::mem::take(&mut m.ai.targets);
                let mut events = Vec::new();
                let mut test_level = crate::health::TestLevel::new(0);
                let level = &mut test_level.level();
                let mut cx = Cx {
                    w: &w,
                    level,
                    events: &mut events,
                };
                for _ in 0..200 {
                    goals.tick(&mut m, &mut cx);
                }
                m.ai.targets = goals;
                assert_eq!(
                    m.ai.target == Some(Who::Player),
                    targets,
                    "universal_anger {universal_anger}, creative {creative}"
                );
            }
        });
    }
}

#[cfg(test)]
mod cat_tempt_tests {
    use super::*;
    use crate::mobs::world::{test_player, with_test_world};
    use horizon_core::geometry::Vec3;
    use std::sync::Arc;

    /// `CatTemptGoal` overrides `canUse` with `!cat.isTame()`, and inherits
    /// `TemptGoal.canContinueToUse`, which calls `canUse()` again: taming the
    /// cat mid-tempt ends the goal. Horizon's `CatTempt::can_continue` ran the
    /// base tempt continue, which never asked whether the cat was tamed.
    #[test]
    fn a_tamed_cat_stops_being_tempted() {
        let mut outcomes = None;
        let ran = with_test_world(&[], |w, types| {
            let kind = Arc::new(types.types["minecraft:cat"].clone());
            let food = kind.food.clone();
            let mut m = Mob::new(1, kind, Vec3::new(0.5, 64.0, 0.5), 0.0);
            let mut world = w.clone();
            let mut p = test_player(Vec3::new(2.5, 64.0, 0.5));
            p.main_hand = Some("minecraft:cod".into());
            world.player = Some(p);
            m.ai.goals.add(
                4,
                CatTempt(super::super::goals::Tempt::new(0.6, food, true), None),
            );
            let mut fixture = crate::health::TestLevel::new(0);
            let mut events = Vec::new();
            let mut cx = Cx {
                w: &world,
                level: &mut fixture.level(),
                events: &mut events,
            };
            let mut goals = std::mem::take(&mut m.ai.goals);
            goals.tick(&mut m, &mut cx);
            let started = goals.is_running("CatTempt");
            m.extra.tame = true;
            goals.tick(&mut m, &mut cx);
            outcomes = Some((started, goals.is_running("CatTempt")));
            m.ai.goals = goals;
        });
        if !ran {
            return;
        }
        assert_eq!(
            outcomes,
            Some((true, false)),
            "a wild cat is tempted; once tamed the same goal must stop"
        );
    }
}

#[cfg(test)]
mod tamable_panic_tests {
    use super::*;
    use crate::mobs::world::with_built_test_world;
    use crate::mobs::{Damage, DamageKind};
    use horizon_core::geometry::Vec3;
    use std::sync::Arc;

    /// Whether the mob's `TamePanic` starts after `damage`, or `None` when
    /// the extracted data is missing.
    fn panics(name: &str, setup: fn(&mut Mob), damage: DamageKind) -> Option<bool> {
        let mut outcome = None;
        let ran = with_built_test_world(
            &[],
            |world, registry| {
                for x in -2..=1 {
                    for z in -2..=1 {
                        world
                            .chunks
                            .insert((x, z), Arc::new(crate::chunk::Chunk::empty(x, z)));
                    }
                }
                let stone = registry.default_state("minecraft:stone").unwrap();
                for x in -8..=8 {
                    for z in -8..=8 {
                        world.set(x, 63, z, stone).unwrap();
                    }
                }
            },
            |w, types| {
                let kind = Arc::new(types.types[name].clone());
                let mut m = Mob::new(1, kind, Vec3::new(0.5, 64.0, 0.5), 0.0);
                setup(&mut m);
                m.on_ground = true;
                m.last_damage = Some((Damage::of(damage), i64::from(m.age)));
                let mut events = Vec::new();
                let mut test_level = crate::health::TestLevel::new(0);
                let mut cx = Cx {
                    w,
                    level: &mut test_level.level(),
                    events: &mut events,
                };
                let mut goals = std::mem::take(&mut m.ai.goals);
                goals.tick(&mut m, &mut cx);
                outcome = Some(goals.is_running("TamePanic"));
                m.ai.goals = goals;
            },
        );
        ran.then_some(outcome).flatten()
    }

    /// `TamableAnimal.TamableAnimalPanicGoal` is built with a damage tag: a
    /// cat's and a parrot's take the default `#panic_causes` (any damage that
    /// makes a mob panic), a wolf's `#panic_environmental_causes` (fire,
    /// freezing, cactus, lightning, lava...).
    #[test]
    fn tamable_animals_panic_from_the_damage_they_fear() {
        // Needs the extracted mob data (`with_built_test_world`); CI has none.
        let (Some(cat), Some(frozen), Some(hit)) = (
            panics("minecraft:cat", register_cat, DamageKind::PlayerAttack),
            panics("minecraft:wolf", register, DamageKind::Freeze),
            panics("minecraft:wolf", register, DamageKind::PlayerAttack),
        ) else {
            eprintln!("skipped: no extracted mob data");
            return;
        };
        assert!(cat, "a cat hit by a player runs");
        assert!(frozen, "a freezing wolf runs");
        assert!(!hit, "a wolf hit by a player does not panic");
    }
}

#[cfg(test)]
mod non_tame_tests {
    use super::*;
    use crate::mobs::world::with_test_world;
    use horizon_core::geometry::Vec3;
    use std::sync::Arc;

    /// `NonTameRandomTargetGoal.canContinueToUse` re-tests the subclass
    /// selector: a baby turtle (`Turtle.BABY_ON_LAND_SELECTOR`) that enters
    /// water is no longer a valid target.
    #[test]
    fn a_non_tame_target_stops_when_the_baby_turtle_enters_water() {
        let mut kinds = None;
        if !with_test_world(&[], |_, types| {
            kinds = Some((
                Arc::new(types.types["minecraft:cat"].clone()),
                Arc::new(types.types["minecraft:turtle"].clone()),
            ));
        }) {
            return;
        }
        let Some((cat, turtle)) = kinds else { return };
        let mut turtle = Mob::new(2, turtle, Vec3::new(2.5, 64.0, 0.5), 0.0);
        turtle.extra.age = -24000;
        let mut m = Mob::new(1, cat, Vec3::new(0.5, 64.0, 0.5), 0.0);
        m.ai.goals.add(
            1,
            NonTameTarget::new(
                NearestTarget::new(Prey::Filter(baby_turtle_on_land), false).interval(0),
            ),
        );
        let tick = |m: &mut Mob, w: &MobWorld| {
            let mut lr = crate::health::TestLevel::new(0);
            let mut events = Vec::new();
            let mut cx = Cx {
                w,
                level: &mut lr.level(),
                events: &mut events,
            };
            let mut goals = std::mem::take(&mut m.ai.goals);
            goals.tick(m, &mut cx);
            let running = goals.is_running("NonTameRandomTargetGoal");
            m.ai.goals = goals;
            running
        };
        let land = [turtle.seen(None)];
        let mut started = None;
        if !with_test_world(&land, |w, _| started = Some(tick(&mut m, w))) {
            return;
        }
        turtle.fluids.in_water = true;
        let water = [turtle.seen(None)];
        let mut stopped = None;
        if !with_test_world(&water, |w, _| stopped = Some(!tick(&mut m, w))) {
            return;
        }
        assert_eq!(
            (started, stopped),
            (Some(true), Some(true)),
            "a baby turtle on land is hunted and one in water is not"
        );
    }
}
