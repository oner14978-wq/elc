//! ClientboundUpdateRecipesPacket: what RecipeManager.finalizeRecipeLoading
//! synchronizes, the recipe property sets (the items each furnace, smithing
//! table slot and brewing stand slot accepts) and the stonecutter's recipes,
//! read from the data pack's recipe files.
use super::data::SyncData;
use horizon_protocol::buf::Writer;
use serde_json::Value;
use std::{
    collections::{BTreeMap, BTreeSet, HashMap},
    path::Path,
    sync::{Arc, Mutex},
};

/// RecipeManager.RECIPE_PROPERTY_SETS: each set and the ingredients it takes
/// from a recipe of the given type.
pub(crate) const PROPERTY_SETS: &[(&str, &str, &[&str])] = &[
    ("smithing_addition", "smithing", &["addition"]),
    ("smithing_base", "smithing", &["base"]),
    ("smithing_template", "smithing", &["template"]),
    ("furnace_input", "minecraft:smelting", &["ingredient"]),
    ("blast_furnace_input", "minecraft:blasting", &["ingredient"]),
    ("smoker_input", "minecraft:smoking", &["ingredient"]),
    (
        "campfire_input",
        "minecraft:campfire_cooking",
        &["ingredient"],
    ),
    ("brewing_input", "minecraft:brewing", &["input"]),
    ("brewing_reagent", "minecraft:brewing", &["reagent"]),
];

/// An ingredient as its HolderSet: a tag, or the items listed.
enum Ingredient {
    Tag(String),
    Items(Vec<String>),
}

fn ingredient(v: &Value) -> Option<Ingredient> {
    match v {
        Value::String(s) => Some(match s.strip_prefix('#') {
            Some(tag) => Ingredient::Tag(tag.to_owned()),
            None => Ingredient::Items(vec![s.clone()]),
        }),
        Value::Array(a) => Some(Ingredient::Items(
            a.iter()
                .filter_map(|s| s.as_str().map(str::to_owned))
                .collect(),
        )),
        // A brewing slot: the item predicate's `item` ingredient.
        Value::Object(o) => ingredient(o.get("item")?),
        _ => None,
    }
}

/// The recipes by id in vanilla's registration order (path, then namespace),
/// the order `RecipeManager` numbers groups and lists the stonecutter's
/// recipes in, and so the order the host's own tables keep.
fn registration_order<V>(all: &BTreeMap<String, V>) -> Vec<&V> {
    let mut ordered: Vec<_> = all.iter().collect();
    ordered.sort_by_cached_key(|(id, _)| horizon_client::crafting::registration_key(id));
    ordered.into_iter().map(|(_, v)| v).collect()
}

/// The network copy's recipes: every recipe file and overlay recipe, each
/// ingredient object — NeoForge's shapes, a brewing slot's item predicate —
/// replaced by the flat item list the crafting copy resolves it to. The
/// crafting copy resolves these shapes where it loads them; this copy reads
/// the files again, and `holder_set` writes any object it meets as an empty
/// list. A recipe that keeps an object the loader cannot parse (a mod's own
/// ingredient kind) is left out: the server does not load it, and an empty
/// ingredient in its place misleads the client.
pub(super) fn network_recipes(
    resources: &Path,
    overlay: &horizon_world::loot::PackOverlay,
    defaults: &horizon_world::item_defaults::ItemDefaults,
    sources: &horizon_client::crafting::ResolvedSources,
) -> (BTreeMap<String, Box<str>>, HashMap<String, i32>) {
    // The resolved copy: the load's `ingredient` answers are in place, and
    // none of them leaves it (`forget_answers` below).
    let mut all: BTreeMap<_, _> = sources
        .recipes
        .iter()
        .map(|r| {
            (
                horizon_client::crafting::qualified(&r.name),
                (*r.resolved).clone(),
            )
        })
        .collect();
    match horizon_client::items::Items::catalog(resources, overlay, defaults) {
        Ok(items) => all.retain(|_, r| normalize_ingredients(r, &items)),
        Err(e) => log::warn!("recipes: NeoForge's ingredient shapes stay unresolved: {e}"),
    }
    all.values_mut().for_each(|r| {
        horizon_client::crafting::Ingredient::forget_answers(r);
    });
    // RecipeManager.unpackRecipeInfo's group numbers, while the files are
    // still parsed.
    let mut groups = HashMap::new();
    for r in registration_order(&all) {
        if let Some(g) = r["group"].as_str().filter(|g| !g.is_empty()) {
            let next = groups.len() as i32;
            groups.entry(g.to_owned()).or_insert(next);
        }
    }
    // Each file as its compact JSON text: a book entry parses the one it
    // needs, and the parsed files would keep about 5 MB alive for the
    // server's whole run.
    let all = all
        .into_iter()
        .map(|(id, r)| (id, r.to_string().into_boxed_str()))
        .collect();
    (all, groups)
}

/// An ingredient object's flat item list: the shape NeoForge's standard
/// kinds resolve to, or a brewing predicate's `item`. `None`: the object is
/// a kind the loader does not know, a mod's own.
fn flat(ing: &Value, items: &horizon_client::items::Items) -> Option<Value> {
    if !ing.is_object() {
        return None;
    }
    let parsed = horizon_client::crafting::Ingredient::parse(ing, items).or_else(|| {
        // A brewing slot's item predicate: its `ingredient`, as the
        // property sets have always read it.
        ing.get("item")
            .and_then(|v| horizon_client::crafting::Ingredient::parse(v, items))
    })?;
    Some(Value::Array(
        parsed
            .order
            .iter()
            .map(|i| Value::String(i.clone()))
            .collect(),
    ))
}

/// Replace each of a recipe's ingredient objects with its flat item list,
/// so `holder_set` writes the items instead of an empty list. `false`: the
/// recipe keeps an object the loader cannot parse.
fn normalize_ingredients(r: &mut Value, items: &horizon_client::items::Items) -> bool {
    let known = r["type"]
        .as_str()
        .is_some_and(|t| t.starts_with("minecraft:"));
    if !known {
        return true;
    }
    let mut parsed = true;
    // The shaped recipe's key: a map of symbols to ingredients.
    if let Some(map) = r.get_mut("key").and_then(|k| k.as_object_mut()) {
        for ing in map.values_mut() {
            if let Some(replacement) = flat(ing, items) {
                *ing = replacement;
            } else if ing.is_object() {
                parsed = false;
            }
        }
    }
    // The list and single-ingredient keys, the smithing trio, the brewing
    // pair.
    for key in [
        "ingredients",
        "ingredient",
        "base",
        "addition",
        "template",
        "input",
        "reagent",
    ] {
        let Some(ing) = r.get_mut(key) else { continue };
        if let Some(replacement) = flat(ing, items) {
            *ing = replacement;
            continue;
        }
        if let Value::Array(a) = ing {
            for entry in a.iter_mut() {
                if let Some(replacement) = flat(entry, items) {
                    *entry = replacement;
                } else if entry.is_object() {
                    parsed = false;
                }
            }
        } else if ing.is_object() {
            parsed = false;
        }
    }
    parsed
}

/// The packet's payload for the network copy's recipes (`network_recipes`).
pub fn update_recipes(
    all: &BTreeMap<String, Box<str>>,
    sync: &SyncData,
    additions: &horizon_client::crafting::PropertyAdditions,
) -> Vec<u8> {
    // The copy is already filtered and swapped (`network_recipes`); the
    // filters never run twice, so one swap cannot feed a later one again.
    // Parsing every recipe takes about a millisecond.
    let chosen: Vec<Value> = registration_order(all)
        .into_iter()
        .filter_map(|text| serde_json::from_str::<Value>(text).ok())
        .collect();
    let tags: BTreeMap<&str, &[i32]> = sync
        .tags
        .registries
        .iter()
        .filter(|r| r.registry == "minecraft:item")
        .flat_map(|r| r.tags.iter())
        .map(|t| (t.name.trim_start_matches("minecraft:"), t.ids.as_slice()))
        .collect();
    // An item the registries do not know is left out, not sent as id 0.
    let item = |name: &str| sync.id("minecraft:item", name);
    let items = |i: &Ingredient| -> Vec<i32> {
        match i {
            Ingredient::Tag(t) => tags
                .get(t.trim_start_matches("minecraft:"))
                .map(|ids| ids.to_vec())
                .unwrap_or_default(),
            Ingredient::Items(list) => list.iter().filter_map(|n| item(n)).collect(),
        }
    };
    let mut w = Writer::new();
    let custom: BTreeMap<_, _> = additions.custom().collect();
    w.varint((PROPERTY_SETS.len() + custom.len()) as i32);
    for (key, kind, fields) in PROPERTY_SETS {
        let mut set = BTreeSet::new();
        for recipe in &chosen {
            let t = recipe["type"].as_str().unwrap_or("");
            let matches = if *kind == "smithing" {
                t.starts_with("minecraft:smithing_")
            } else {
                t == *kind
            };
            if matches {
                for field in *fields {
                    if let Some(i) = ingredient(&recipe[*field]) {
                        set.extend(items(&i));
                    }
                }
            }
        }
        // An item the registries do not know is left out (`item`).
        set.extend(
            additions
                .get(key)
                .into_iter()
                .flatten()
                .filter_map(|n| item(n)),
        );
        w.string(&format!("minecraft:{key}"));
        w.varint(set.len() as i32);
        for id in set {
            w.varint(id);
        }
    }
    for (key, names) in custom {
        let ids: BTreeSet<_> = names.iter().filter_map(|name| item(name)).collect();
        w.string(key);
        w.varint(ids.len() as i32);
        for id in ids {
            w.varint(id);
        }
    }
    // SelectableRecipe.SingleInputSet: each stonecutting recipe's input and
    // its result as an ItemStackSlotDisplay.
    let stonecutting: Vec<&Value> = chosen
        .iter()
        .filter(|r| r["type"] == "minecraft:stonecutting")
        .collect();
    let item_stack = sync
        .id("minecraft:slot_display", "minecraft:item_stack")
        .unwrap_or(0);
    w.varint(stonecutting.len() as i32);
    for r in stonecutting {
        match ingredient(&r["ingredient"]) {
            Some(Ingredient::Tag(t)) => {
                w.varint(0);
                w.string(&t);
            }
            Some(i) => {
                let ids = items(&i);
                w.varint(ids.len() as i32 + 1);
                for id in ids {
                    w.varint(id);
                }
            }
            None => w.varint(1),
        }
        w.varint(item_stack);
        w.varint(
            item(horizon_world::loot::recipe_result_id(&r["result"]).unwrap_or("minecraft:air"))
                .unwrap_or(0),
        );
        w.varint(r["result"]["count"].as_i64().unwrap_or(1) as i32);
        w.varint(0); // no components added
        w.varint(0); // nor removed
    }
    w.data
}

/// The Horizon channel a server sends its clients the recipes its native mods
/// asked for (`native_datapack_sync`), NeoForge's
/// `OnDatapackSyncEvent.sendRecipes`. Horizon clients only.
pub const CONTENT_CHANNEL: &str = "horizon:recipe_content";
/// `ClientboundCustomPayloadPacket`'s cap on a payload, less room for the
/// envelope.
const CONTENT_MAX: usize = 1_048_576 - 1024;

/// One payload of the recipe content: some recipes as `(id, json)`, and on the
/// last one the recipe types they replace on the client (a type the server has
/// no recipe of still empties the client's).
#[derive(Debug, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct ContentPart {
    pub recipes: Vec<(String, Value)>,
    pub last: Option<Vec<String>>,
}
impl ContentPart {
    /// Decode a content part only within the same bound used by the sender.
    pub fn decode(data: &[u8]) -> Result<Self, String> {
        if data.len() > CONTENT_MAX {
            return Err(format!("recipe content exceeds {CONTENT_MAX} bytes"));
        }
        serde_json::from_slice(data).map_err(|error| error.to_string())
    }
}

/// The payloads for `types`' recipes among `sources` (`recipe_sources::sources`,
/// vanilla's ids bare), ids made whole (`minecraft:<name>`). With no type
/// asked for: nothing, or with `reset` (this server sent recipes before) one
/// last part with no types, which puts its clients back on their own. A
/// recipe too big for a payload of its own is left out.
pub fn encode_content(types: &[String], sources: &[(String, Value)], reset: bool) -> Vec<Vec<u8>> {
    // The last part carries the types: they count against its cap too.
    let types_len = serde_json::to_string(types).map_or(0, |t| t.len()) + 32;
    if types_len > CONTENT_MAX {
        log::warn!("Horizon: too many recipe types to send to clients");
        return Vec::new();
    }
    if types.is_empty() && !reset {
        return Vec::new();
    }
    let mut out = Vec::new();
    let mut part: Vec<(String, Value)> = Vec::new();
    let mut size = 0;
    for (name, v) in sources {
        if !types.iter().any(|t| v["type"].as_str() == Some(t)) {
            continue;
        }
        let id = if name.contains(':') {
            name.clone()
        } else {
            format!("minecraft:{name}")
        };
        let len = id.len() + v.to_string().len() + 8;
        if len > CONTENT_MAX {
            log::warn!("Horizon: recipe {id} is too big to send to clients");
            continue;
        }
        if size + len > CONTENT_MAX {
            let recipes = std::mem::take(&mut part);
            out.push(
                serde_json::to_vec(&ContentPart {
                    recipes,
                    last: None,
                })
                .unwrap_or_default(),
            );
            size = 0;
        }
        size += len;
        part.push((id, v.clone()));
    }
    if size + types_len > CONTENT_MAX {
        let recipes = std::mem::take(&mut part);
        out.push(
            serde_json::to_vec(&ContentPart {
                recipes,
                last: None,
            })
            .unwrap_or_default(),
        );
    }
    let last = ContentPart {
        recipes: part,
        last: Some(types.to_vec()),
    };
    out.push(serde_json::to_vec(&last).unwrap_or_default());
    out
}

/// What the server sends its Horizon clients now (`set_content`).
static CONTENT: Mutex<Option<Arc<Vec<Vec<u8>>>>> = Mutex::new(None);

/// The recipe content the server sends from now on, at a join and after a
/// `/reload` (one server per process, as `lan::sync_data`).
pub fn set_content(payloads: Vec<Vec<u8>>) {
    if !payloads.is_empty() {
        SENT.store(true, std::sync::atomic::Ordering::Relaxed);
    }
    *CONTENT.lock().unwrap_or_else(|e| e.into_inner()) = Some(Arc::new(payloads));
}

/// Whether this server sent its clients recipes before: a later load that
/// asks for none must put them back on their own (`encode_content`'s reset).
static SENT: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);

pub fn sent_before() -> bool {
    SENT.load(std::sync::atomic::Ordering::Relaxed)
}

/// The payloads to send a Horizon client; none when no mod asked.
pub fn content() -> Arc<Vec<Vec<u8>>> {
    CONTENT
        .lock()
        .unwrap_or_else(|e| e.into_inner())
        .clone()
        .unwrap_or_default()
}

/// Horizon recipe viewer transfer channel.
pub const TRANSFER_CHANNEL: &str = "horizon:recipe_transfer";

/// Decode a transfer request: container, bounded recipe id, optional all flag.
pub fn decode_transfer_request(data: &[u8]) -> horizon_protocol::Result<(i32, String, bool)> {
    let mut reader = horizon_protocol::buf::Reader::new(data);
    let container = reader.varint()?;
    let id = reader.string(512)?;
    let all = match reader.remaining() {
        0 => false,
        1 => reader.u8()? == 1,
        _ => {
            return Err(horizon_protocol::Error::new(
                "recipe transfer request: trailing bytes",
            ));
        }
    };
    Ok((container, id, all))
}

/// Decode a fixed-shape transfer result, or an empty feature advertisement.
pub fn decode_transfer_reply(data: &[u8]) -> horizon_protocol::Result<Option<(i32, u8)>> {
    if data.is_empty() {
        return Ok(None);
    }
    let mut reader = horizon_protocol::buf::Reader::new(data);
    let reply = (reader.varint()?, reader.u8()?);
    if reader.remaining() != 0 {
        return Err(horizon_protocol::Error::new(
            "recipe transfer reply: trailing bytes",
        ));
    }
    Ok(Some(reply))
}

#[cfg(test)]
mod content_tests {
    use super::*;
    use horizon_client::crafting::ResolvedSources;
    use serde_json::json;

    use horizon_world::native_load_context::{
        DataLoadOrigin as EngineDataLoadOrigin, LoadContext, LoadInputs,
    };
    use mod_api::DataLoadOrigin;

    struct AspectListener(std::sync::Arc<std::sync::Mutex<Vec<(DataLoadOrigin, String)>>>);
    #[mod_api::__subscriptions]
    impl mod_api::Hooks for AspectListener {
        fn ingredient(
            &self,
            context: &dyn mod_api::DataLoadContext,
            event: &mut mod_api::IngredientEvent<'_>,
        ) {
            self.0.lock().unwrap().push((
                context.origin(),
                match event.data.get(&"aspect".into()).unwrap() {
                    horizon_core::nbt::Tag::String(s) => format!("\"{}\"", s.to_string().unwrap()),
                    other => panic!("expected aspect string, got {other:?}"),
                },
            ));
            event.items.push("minecraft:emerald".into());
        }
    }

    fn load(origin: EngineDataLoadOrigin) -> LoadContext {
        LoadContext::new(
            origin,
            std::sync::Arc::new(LoadInputs::new(Default::default(), Default::default())),
            [],
        )
    }

    /// The `ingredient` hook hears each custom-ingredient occurrence once per
    /// load, in the load's own pass (`ResolvedSources::resolve`), whatever
    /// reads the recipes afterwards: every parse and the guests' copy read the
    /// answer the pass left. The occurrence under a slot other than
    /// `ingredients` (a banner recipe's `banner`) and the nested one are
    /// answered too, and an answer a data file carries is dropped. Measured
    /// in the game before the pass existed, per occurrence: an integrated
    /// open heard it twice with `ServerDataLoad` and once with `ClientPreload`,
    /// and a dedicated server three times.
    #[test]
    fn ingredient_hook_hears_each_occurrence_once_per_load_with_its_origin() {
        let heard = std::sync::Arc::new(std::sync::Mutex::new(Vec::new()));
        let mods = vec![mod_api::ModEntry::new(
            "aspects",
            Box::new(AspectListener(heard.clone())),
        )];
        let items = horizon_client::items::Items::for_tests(Default::default());
        let recipe = json!({
            "type": "minecraft:crafting_shapeless",
            "ingredients": [
                {"type": "neoforge:compound", "children": [
                    {"type": "mymod:aspect", "aspect": "nested"}, "minecraft:stone"]},
                {"type": "mymod:aspect", "aspect": "plain"}
            ],
            "banner": {"type": "mymod:aspect", "aspect": "banner",
                "horizon:resolved_items": ["minecraft:diamond"]},
            "result": {"id": "minecraft:stick", "count": 1}
        });
        let sources = || vec![("aspects_test".to_owned(), recipe.clone())];
        mod_api::testing::with_mods(mods.into(), || {
            let server_origin = DataLoadOrigin::ServerDataLoad;
            let resolved =
                ResolvedSources::resolve(sources(), &load(EngineDataLoadOrigin::ServerDataLoad));
            let once = heard.lock().unwrap().clone();
            assert_eq!(
                once,
                [
                    (server_origin, "\"nested\"".to_owned()),
                    (server_origin, "\"plain\"".to_owned()),
                    (server_origin, "\"banner\"".to_owned()),
                ]
            );

            // Parsing again, and the guests' copy, hear nothing more, and the
            // forged answer on the banner slot was replaced by the hook's.
            let file = &resolved.recipes[0].resolved;
            let banner =
                horizon_client::crafting::Ingredient::parse(&file["banner"], &items).unwrap();
            assert_eq!(banner.order, ["minecraft:emerald"]);
            for ingredient in file["ingredients"].as_array().unwrap() {
                horizon_client::crafting::Ingredient::parse(ingredient, &items).unwrap();
            }
            let mut copy = (**file).clone();
            assert!(normalize_ingredients(&mut copy, &items));
            assert_eq!(heard.lock().unwrap().len(), 3);
            // What the pass left is not the file the mods and clients see.
            assert_eq!(*resolved.recipes[0].file, recipe);
            horizon_client::crafting::Ingredient::forget_answers(&mut copy);
            assert!(!copy.to_string().contains("resolved_items"));

            heard.lock().unwrap().clear();
            let client =
                ResolvedSources::resolve(sources(), &load(EngineDataLoadOrigin::ClientPreload));
            assert!(
                heard
                    .lock()
                    .unwrap()
                    .iter()
                    .all(|(origin, _)| *origin == DataLoadOrigin::ClientPreload)
            );
            assert_eq!(heard.lock().unwrap().len(), 3);
            drop(client);
        });
    }

    struct PropertyListener(std::sync::Arc<std::sync::Mutex<Vec<DataLoadOrigin>>>);
    #[mod_api::__subscriptions]
    impl mod_api::Hooks for PropertyListener {
        fn recipe_property_sets(
            &self,
            context: &dyn mod_api::DataLoadContext,
            event: &mut mod_api::RecipePropertySetsEvent<'_>,
        ) {
            self.0.lock().unwrap().push(context.origin());
            let add = |set: &str, items: &[&str]| {
                mod_api::RecipePropertyAddition::new(
                    set,
                    items.iter().map(|i| (*i).to_owned()).collect(),
                )
            };
            event.additions.push(add(
                "minecraft:furnace_input",
                &["minecraft:emerald", "minecraft:air"],
            ));
            event
                .additions
                .push(add("minecraft:no_such_set", &["minecraft:dirt"]));
            event
                .additions
                .push(add("brewing_reagent", &["minecraft:diamond"]));
        }
    }

    /// The `recipe_property_sets` hook is asked once per load with the load's
    /// origin; the resolved set keeps the known sets' items (a set key with or
    /// without `minecraft:`), drops air and unknown sets, and the furnace
    /// takes what a mod added though no recipe names it.
    #[test]
    fn property_sets_are_asked_once_per_load_and_validated() {
        let heard = std::sync::Arc::new(std::sync::Mutex::new(Vec::new()));
        let mods = vec![mod_api::ModEntry::new(
            "props",
            Box::new(PropertyListener(heard.clone())),
        )];
        mod_api::testing::with_mods(mods.into(), || {
            let resolved =
                ResolvedSources::resolve(Vec::new(), &load(EngineDataLoadOrigin::ServerDataLoad));
            assert_eq!(*heard.lock().unwrap(), [DataLoadOrigin::ServerDataLoad]);
            let added = &resolved.property_additions;
            assert!(added.adds("furnace_input", "minecraft:emerald"));
            assert!(!added.adds("furnace_input", "minecraft:air"));
            assert!(added.adds("brewing_reagent", "minecraft:diamond"));
            assert!(added.get("no_such_set").is_none());
            assert!(!added.adds("smoker_input", "minecraft:emerald"));
        });
    }

    /// Every slot `Recipes`, `StationRecipes` and the guests' copy read an
    /// ingredient from (the keys their readers name, listed here from them),
    /// the shaped `key` and the firework star's `shapes` maps among them,
    /// carries a mod ingredient that parses after the pass: none fails where
    /// it worked before the pass.
    #[test]
    fn every_slot_the_readers_use_is_answered_by_the_pass() {
        let heard = std::sync::Arc::new(std::sync::Mutex::new(Vec::new()));
        let mods = vec![mod_api::ModEntry::new(
            "aspects",
            Box::new(AspectListener(heard.clone())),
        )];
        let items = horizon_client::items::Items::for_tests(Default::default());
        let slots = [
            "ingredient",
            "ingredients",
            "base",
            "addition",
            "template",
            "input",
            "reagent",
            "banner",
            "target",
            "material",
            "dye",
            "source",
            "shell",
            "fuel",
            "star",
            "trail",
            "twinkle",
            "map",
            "back",
            "left",
            "right",
            "front",
        ];
        let mut recipe = json!({"type": "minecraft:crafting_special_firework_star"});
        for slot in slots {
            recipe[slot] = json!({"type": "mymod:aspect", "aspect": slot});
        }
        recipe["key"] = json!({"a": {"type": "mymod:aspect", "aspect": "key"}});
        recipe["shapes"] = json!({"star": {"type": "mymod:aspect", "aspect": "shapes"}});
        mod_api::testing::with_mods(mods.into(), || {
            let resolved = ResolvedSources::resolve(
                vec![("slots".to_owned(), recipe.clone())],
                &load(EngineDataLoadOrigin::ServerDataLoad),
            );
            assert_eq!(heard.lock().unwrap().len(), slots.len() + 2);
            let file = &resolved.recipes[0].resolved;
            let parse = |ingredient: &Value| {
                horizon_client::crafting::Ingredient::parse(ingredient, &items)
                    .unwrap_or_else(|| panic!("{ingredient} fails to parse"))
            };
            for slot in slots {
                parse(&file[slot]);
            }
            parse(&file["key"]["a"]);
            parse(&file["shapes"]["star"]);
        });
    }

    #[test]
    fn content_decode_bounds_before_deserializing() {
        let mut body = br#"{"recipes":[],"last":null}"#.to_vec();
        body.resize(1_047_552, b' ');
        assert_eq!(ContentPart::decode(&body).unwrap().recipes, vec![]);
        body.push(b' ');
        assert!(ContentPart::decode(&body).unwrap_err().contains("exceeds"));
    }

    #[test]
    fn content_keeps_the_asked_types_and_ends_with_them() {
        let sources = vec![
            ("furnace".to_owned(), json!({"type": "minecraft:smelting"})),
            (
                "stick".to_owned(),
                json!({"type": "minecraft:crafting_shaped"}),
            ),
            ("mymod:crush".to_owned(), json!({"type": "mymod:crusher"})),
        ];
        assert!(encode_content(&[], &sources, false).is_empty());
        // After a sync that sent recipes, asking for none sends an empty last part.
        let reset = encode_content(&[], &sources, true);
        assert_eq!(reset.len(), 1);
        let part: ContentPart = serde_json::from_slice(&reset[0]).unwrap();
        assert!(part.recipes.is_empty());
        assert_eq!(part.last.as_deref(), Some(&[][..]));
        let types = vec![
            "minecraft:smelting".to_owned(),
            "mymod:crusher".to_owned(),
            "x:none".to_owned(),
        ];
        let parts = encode_content(&types, &sources, false);
        assert_eq!(parts.len(), 1);
        let part: ContentPart = serde_json::from_slice(&parts[0]).unwrap();
        let ids: Vec<&str> = part.recipes.iter().map(|(id, _)| id.as_str()).collect();
        assert_eq!(ids, ["minecraft:furnace", "mymod:crush"]);
        assert_eq!(part.last.as_deref(), Some(types.as_slice()));
    }

    #[test]
    fn content_splits_under_the_payload_cap() {
        let big = "x".repeat(300_000);
        let sources: Vec<_> = (0..10)
            .map(|i| (format!("m:r{i}"), json!({"type": "m:t", "pad": big})))
            .collect();
        let parts = encode_content(&["m:t".to_owned()], &sources, false);
        assert!(parts.len() >= 3);
        let mut n = 0;
        for (i, p) in parts.iter().enumerate() {
            assert!(p.len() <= 1_048_576);
            let part: ContentPart = serde_json::from_slice(p).unwrap();
            assert_eq!(part.last.is_some(), i + 1 == parts.len());
            n += part.recipes.len();
        }
        assert_eq!(n, 10);
    }

    #[test]
    fn a_long_type_list_keeps_the_last_part_under_the_cap() {
        let types: Vec<String> = (0..5000)
            .map(|i| format!("mod{i}:type_with_a_long_name"))
            .collect();
        let big = "x".repeat(1_000_000);
        let sources = vec![(
            "m:r".to_owned(),
            json!({"type": "mod0:type_with_a_long_name", "pad": big}),
        )];
        let parts = encode_content(&types, &sources, false);
        assert_eq!(parts.len(), 2);
        assert!(parts.iter().all(|p| p.len() <= 1_048_576));
        let last: ContentPart = serde_json::from_slice(&parts[1]).unwrap();
        assert!(last.recipes.is_empty());
        assert_eq!(last.last.map(|t| t.len()), Some(5000));
    }
}
